using System;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace DemoMessenger {
    class Messenger 
    {        
        public static void Main(string[] args) 
        {
            string host;
            int port = 25;

            if (args.Length == 0)
            {
                Console.WriteLine("Usage: messenger SMTP_SERVER");
                return;
            }
            else
                host = args[0];
            // Implement the functionality here:
            
        }        
    }
}
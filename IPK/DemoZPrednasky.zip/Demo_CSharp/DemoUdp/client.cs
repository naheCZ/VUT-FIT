using System;
using System.Text;
using System.IO;
using System.Net;
using System.Net.Sockets;

namespace DemoMessenger {
    class UdpClient
    {        
        public static void Main(string[] args) 
        {
            var buffer = new byte[1024];
            string host = String.Empty;
            int port = 0;

            if (args.Length != 2)
            {
                Console.WriteLine("Usage: client SERVER PORT");
                return;
            }
            else
            {
                host = args[0];
                port = Int32.Parse(args[1]);
            }
            
            var input = Console.ReadLine();
            byte[] msg = Encoding.ASCII.GetBytes(input);
            
            // Implement the functionality here:
            try {
                IPHostEntry ipHostInfo = Dns.GetHostEntry(host);
                IPAddress ipAddress = ipHostInfo.AddressList[0];
                IPEndPoint remoteEP = new IPEndPoint(ipAddress,port);
                
                Socket clientSocket = new Socket(AddressFamily.InterNetwork, 
                    SocketType.Dgram, ProtocolType.Udp );
                
                clientSocket.SendTo(msg, remoteEP); 
                 
                EndPoint senderRemote = (EndPoint)remoteEP;            
                clientSocket.ReceiveFrom(buffer, ref senderRemote);
                
                clientSocket.Close();
                
                var received = Encoding.ASCII.GetString(buffer);
                Console.WriteLine(received);
            }
            catch (Exception e)
            {
                Console.WriteLine("ERROR: {0}", e.Message);
            }
        }        
    }
}
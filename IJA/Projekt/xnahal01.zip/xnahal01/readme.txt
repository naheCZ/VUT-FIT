Název aplikace: Klondike
Autoři: Roman Nahálka (xnahal01@stud.fit.vutbr.cz)
        Adam Živčák (xzivca03@stud.fit.vutbr.cz)
Datum:  8.5.2017        
Popis:  Implementace hry Solitaire, přesněji ve verzi Klondike pro předmět Jazyk
        Java vyučovaný na FIT VUT v Brně.
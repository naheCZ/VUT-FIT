/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import model.cards.CardDeck;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 *
 * @author Roman
 */
public class WastedPanel extends JLayeredPane implements DeckPanelInterface
{
    private BufferedImage img;
    private CardDeck deck;

    public CardDeck getDeck() {
        return deck;
    }



    public void setDeck(CardDeck deck)
    {
        this.deck = deck;

        if (this.deck.size() != 0) {
            this.drawCards();
            this.setVisible(true);
        }
        else {
            this.removeCards();
            this.setVisible(false);
        }
    }

    public WastedPanel()
    {       
        super();
        setOpaque(false);
        //setLayout(null);


    }

    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(100, 150);
    }
    
    public void removeBorder()
    {
        this.setBorder(null);
    }

    @Override
    protected void paintComponent(Graphics g)
    {
        super.paintComponent(g);

        if(img != null)
        {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.drawImage(img, 0, 0, null);

            g2d.dispose();
        }
    }
    


    @Override
    public void revalidate()
    {
        super.revalidate();
        System.out.println("som v revalidate wastedpanelu");
        if(this.deck != null)
            this.drawCards();
    }

    public void drawCards()
    {
        this.setLayout(new OverlayLayout(this));
        CardPanel card = new CardPanel(this.deck.get());
        this.add(card, 0);
        if (this.deck.size() > 0)
            this.setVisible(true);
        else
            this.removeCards();
        //this.revalidate();
        this.repaint();
    }


    public void removeCards()
    {
        System.out.println("..som v remove cards");
        if (this.getComponentCount() != 0)
            this.removeAll();
        this.setVisible(false);

        this.repaint();
    }

    public void popCards(){
        while (deck.size()>0)
            deck.pop();
    }
}

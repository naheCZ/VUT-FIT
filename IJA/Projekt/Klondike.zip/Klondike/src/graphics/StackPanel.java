/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import model.cards.CardStack;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;


/**
 *
 * @author Roman
 */
public class StackPanel extends JLayeredPane implements StackPanelInterface
{
    private BufferedImage img;
    private CardStack stack;
    
    public StackPanel()
    {       
        super();
        setOpaque(false);
        setLayout(null);
        this.setBorder(BorderFactory.createLineBorder(Color.red));
    }
    
    /*@Override
    public Dimension getPreferredSize()
    {
        return new Dimension(100, 150);
    }*/
    
    public void removeBorder()
    {
        this.setBorder(null);
    }

    public void setStack(CardStack stack)
    {
        this.stack = stack;
        this.removeBorder();
        this.drawCards();
    }

    @Override
    public CardStack getStack() {
        return stack;
    }

    @Override
    public void revalidate(){
        super.revalidate();
        System.out.println("som v revalidate STACKU");
        if(this.stack != null)
            this.drawCards();
    }

    public void drawCards()
    {               
        this.setLayout(new OverlayLayout(this));
        
        for(int i = 0; i < this.stack.size(); i++)
        {
            CardPanel card = new CardPanel(this.stack.get(i));
            this.add(card, 0);
        }
    }
}

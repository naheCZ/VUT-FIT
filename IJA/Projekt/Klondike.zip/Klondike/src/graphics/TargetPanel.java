/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import model.cards.CardDeck;
import model.cards.CardDeckKlondike;

import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;

/**
 *
 * @author Roman
 */
public class TargetPanel extends JPanel implements DeckPanelInterface
{


    private BufferedImage img;
    private CardDeck deck = new CardDeckKlondike();

    public CardDeck getDeck() {
        return deck;
    }

    @Override
    public void setDeck(CardDeck deck) {
        this.deck = deck;
    }

    public TargetPanel()
    {       
        super();
        setOpaque(false);
        setLayout(null);
        this.setBorder(BorderFactory.createLineBorder(Color.black));
    }
    
    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(100, 150);
    }

    @Override
    public void revalidate(){
        super.revalidate();
        System.out.println("som v revalidate TARGET panelu");
        if(this.deck != null)
            this.drawCards();
    }

    public void drawCards()
    {
        this.setLayout(new OverlayLayout(this));

        for(int i = 0; i < this.deck.size(); i++)
        {
            CardPanel card = new CardPanel(this.deck.get(i));
            this.add(card, 0);
        }
    }
}

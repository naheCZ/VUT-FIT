/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import model.cards.CardDeck;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 *
 * @author Roman
 */
public class MainDeckPanel extends JPanel implements DeckPanelInterface
{
    private BufferedImage img;
    private CardDeck deck;


    public CardDeck getDeck() {
        return deck;
    }

    public void setDeck(CardDeck deck)
    {
        this.deck = deck;
    }

    public MainDeckPanel()
    {
        setOpaque(false);
        
        try
        {
            img = ImageIO.read(getClass().getResource("/cards/Back.png"));
        }
        
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(100, 150);
    }
    
    @Override
    protected void paintComponent(Graphics g)
    {        
        super.paintComponent(g);
        
        if(img != null)
        {
            Graphics2D g2d = (Graphics2D) g.create();
            g2d.drawImage(img, 0, 0, null);
        
            g2d.dispose();
        }
    }
    

    
    public void emptyDeck()
    {
        this.setImg();
        //this.revalidate();
        //this.repaint();
        //this.setBorder(new LineBorder(Color.black));
    }
    
    public void fullDeck()
    {
        //this.setBorder(null);
        
        this.setImg();
    }

    public void setImg(){
        this.setBorder(null);
        try
        {
            if(this.deck.size() == 0)
                img = ImageIO.read(getClass().getResource("/cards/reload2.png"));
            else
                img = ImageIO.read(getClass().getResource("/cards/Back.png"));
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
        this.revalidate();
        this.repaint();
    }
}

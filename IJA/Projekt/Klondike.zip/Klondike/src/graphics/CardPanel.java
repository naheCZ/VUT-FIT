/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import model.cards.Card;
import model.cards.CardDeck;
import model.cards.CardStack;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseMotionAdapter;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 * @author Roman
 */




public class CardPanel extends JPanel {
    public static final int WASTE = 0;
    public static final int FOUNDATION = 1;
    public static final int WORKING = 2;

    private BufferedImage img;
    private Card card;

    private Container table;
    private Container stack_from;
    private Container stack_to;

    private Point point;

    public Card getCard() {
        return card;
    }

    private CardPanel getCardPanel() {
        return this;
    }

    private void setStack_from(Container stack_from) {
        this.stack_from = stack_from;
    }

    private Container getStack_from() {
        return stack_from;
    }

    private void setTable(Container table) {
        this.table = table;
    }

    private Container getTable() {
        return table;
    }

    private void setStack_to(Container stack_to) {
        this.stack_to = stack_to;
    }

    private Container getStack_to() {
        return stack_to;
    }

    private void setPoint(Point point) {
        this.point = point;
    }

    private Point getPoint() {
        return point;
    }

    public CardPanel(Card card) {
        this.card = card;
        setOpaque(false);

        if (card == null) {
            try {
                img = ImageIO.read(getClass().getResource("/cards/empty.png"));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        } else {
            try {
                if (card.isTurnedFaceUp())
                    img = ImageIO.read(getClass().getResource(card.getImage()));
                else
                    img = ImageIO.read(getClass().getResource("/cards/Back.png"));
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }

        addMouseMotionListener(new MouseMotionAdapter() {

            @Override
            public void mouseDragged(MouseEvent me) {
                me.translatePoint(me.getComponent().getLocation().x, me.getComponent().getLocation().y);
                JPanel p = getCardPanel();
                p.setLocation(me.getX(), me.getY());

                //Container par = p.getParent();
                //Container table = par.getParent();
                //par.remove(p);


                //par.revalidate();
                //table.add(p);
                //repaint();
                //par.repaint();
                //revalidate();
            }

            @Override
            public void mouseMoved(MouseEvent e) {
            }
        });


        addMouseListener(new MouseAdapter() {
            @Override
            public void mousePressed(MouseEvent me) {
                JPanel p = getCardPanel();

                System.out.println(p.getParent().getComponentCount());

//                p.getParent().revalidate();

                setTable(p.getParent().getParent());
                setStack_from(p.getParent());
                //getStack_from().setBackground(Color.getColor("u", 2));
                getStack_from().repaint();
                
                getStack_from().remove((p));
                getTable().add(p);

                System.out.println(getStack_from().getComponentCount());

                //setPoint(getLocation());
            }


            @Override
            public void mouseReleased(MouseEvent me) {
                Container table = getTable();
                Container stack_from = getStack_from();

                setStack_to((Container) table.getComponentAt(getLocation()));
                if (getStack_to() == null) {
                    System.out.println("JE TO NULL !!!!!!!!!!!!!");
                    return;
                }

                Component cmp_to = table.getComponentAt(getLocation());

                CardDeck card_st_to;
                if (cmp_to instanceof DeckPanelInterface) {
                    card_st_to = ((DeckPanelInterface) cmp_to).getDeck();
                    System.out.println("položil som to na DECK");
                } else if (cmp_to instanceof StackPanelInterface) {
                    card_st_to = ((StackPanelInterface) cmp_to).getStack();
                    System.out.println("položil som to na STACK");
                } else {
                    System.out.println("položil som to mimo");
                    return_card();
                    return;
                }

                CardDeck card_st_from;
                if (stack_from instanceof WastedPanel) {
                    card_st_from = ((WastedPanel) stack_from).getDeck();
                    System.out.println("bral som to z wastedpanelu");
                } else if (stack_from instanceof StackPanelInterface) {
                    card_st_from = ((StackPanelInterface) stack_from).getStack();
                    System.out.println("bral som to na STACK 2");
                } else {
                    System.out.println("bral som to odniekiaľ inam -> koniec");
                    return;
                }


                if (card_st_to.checkPut(getCard())) {
                    System.out.println("   možeš to tam položiť");
                    put_card(card_st_from, card_st_to);
                } else {
                    System.out.println("   NEmožeš to tam položiť\n");
                    return_card();
                }

            }
        });
    }


    private void put_card(CardDeck card_st_from, CardDeck card_st_to) {

        if (card_st_from instanceof CardStack) System.out.println("bral som to zo stacku");
        else System.out.println("bral som to z decku");

        if (card_st_to instanceof CardStack) System.out.println("pokladam  to na stack");
        else System.out.println("pokladam  to na  deck");
        System.out.println("\n");


        Card c = card_st_from.pop();
        card_st_to.put(c);
        card_st_from.rotateLastCard();

        Container xx = getStack_to();
        if (xx == null) {
            System.out.println("xx je null");
            return;
        }
        xx.add(getCardPanel());
        xx.revalidate();
        xx.repaint();

        getTable().remove(getCardPanel());
        getTable().revalidate();
        getTable().repaint();

        getStack_from().revalidate();
        getStack_from().repaint();
    }

    private void return_card() {
        getStack_from().getParent().add(getCardPanel());
        getStack_from().revalidate();
        getStack_from().repaint();

        getTable().remove(getCardPanel());
        getTable().revalidate();
        getTable().repaint();


    }

    /**
     * zistiť kde som to pustil
     * zistiť či je možné to tam položiť
     * ak ano - odobrať z cmp_from (aj logicky, aj graficky)
     * - na cmp from otočiť kartu ak tam ešte nejaká je
     * - pridat na cmp_to (aj logicky, aj graficky)
     * ak nie - vrátiť na pôvodné miesto
     **/


/*    =========================================================================

            System.out.println(toString());

                if (cmp_from instanceof WastedPanel)
    {
        System.out.println("pretypovane...");;
        waste= (WastedPanel)cmp_from;
    }

                if (cmp_to instanceof TargetPanel){
    System.out.println("položil som to na TARGET panel");
    TargetPanel target = (TargetPanel)cmp_to;

    if (target.getDeck().checkPut(card)) {
        System.out.println("možeš to tam položiť");

        target.getDeck().put(card);
        waste.getDeck().pop();







         } else {
         System.out.println("NEmožeš to tam položiť");
         table.remove(panel);
         stack.add(panel);
         stack.revalidate();
         table.revalidate();
         table.repaint();
         }
         }
         /*else if (cmp instanceof TablePanel)
         System.out.println("položil som to na  TABLE panel");
         else if (cmp instanceof StackPanel)
         System.out.println("položil som to na STACK panel");
         *            else {
         System.out.println("položil som to na  TABLE alebo STACK alebo WASTE  panel");

         }*/

//  ==========================================================================
    @Override
    public Dimension getPreferredSize() {
        return new Dimension(100, 150);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        g2d.drawImage(img, 0, 0, null);

        g2d.dispose();
    }
}

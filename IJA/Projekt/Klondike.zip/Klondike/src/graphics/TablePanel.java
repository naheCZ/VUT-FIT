/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphics;

import javax.imageio.ImageIO;
import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.IOException;

/**
 *
 * @author Roman
 */
public class TablePanel extends JPanel
{
    private BufferedImage img;
    
    public TablePanel()
    {
        setVisible(true);
        setOpaque(false);

        try
        {
            img = ImageIO.read(getClass().getResource("/Table.png"));
        }
        
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }
    
    @Override
    public Dimension getPreferredSize()
    {
        return new Dimension(1024, 390);
    }
    
    @Override
    protected void paintComponent(Graphics g)
    {
        int width;
        int height;
        
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g.create();
        
        width = img.getWidth();
        height = img.getHeight();
        
        for(int y = 0; y < getHeight(); y += height)
        {
            for(int x = 0; x < getWidth(); x += width)
                g2d.drawImage(img, x, y, null);
        }
        
        g2d.dispose();
    }
}

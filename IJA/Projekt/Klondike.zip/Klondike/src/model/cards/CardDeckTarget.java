/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model.cards;

import java.util.ArrayList;

/**
 *
 * @author Roman
 */
public class CardDeckTarget implements CardDeck
{
    private int size;
    private ArrayList<Card> cards;
    private Card.Color color;

    public CardDeckTarget(int size, Card.Color color)
    {
        this.size = size;
        this.cards = new ArrayList<Card>();
        this.color = color;
    }

    @Override
    public int size()
    {
        return this.getCards().size();
    }

    @Override
    public boolean put(Card card)
    {
        boolean empty = this.isEmpty();
        
        if(card.color() != this.color)
            return false;
        
        if(empty)
        {
            if(card.value() == 1)
            {
                this.cards.add(card);
                return true;
            }
            
            else
                return false;
        }
        
        else
        {
            int diff = card.compareValue(this.cards.get(this.cards.size() - 1));
            
            if(diff == 1)
            {
                this.cards.add(card);
                return true;
            }
            
            else
                return false;
        }
    }

    @Override
    public Card pop()
    {
        int size = this.getCards().size();
        Card removed;

        if(size == 0)
            return null;

        removed = this.getCards().remove(size - 1);

        return removed;
    }

    @Override
    public Card get()
    {
        int size = this.getCards().size();

        if(size == 0)
            return null;

        else
            return this.getCards().get(size - 1);
    }

    @Override
    public Card get(int index)
    {
        int size = this.getCards().size();

        if((index < 0) || index > (size - 1))
            return null;

        else
            return this.getCards().get(size - 1);
    }

    @Override
    public boolean isEmpty()
    {
        return this.getCards().isEmpty();
    }

    public ArrayList<Card> getCards()
    {
        return cards;
    }

    public Card.Color getColor()
    {
        return color;
    }

    @Override
    public void put(Card.Color c, int value) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void shuffleCards() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public boolean checkPut(Card card) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void rotateLastCard() {

    }
}

package model.board;

import model.cards.Card;
import model.cards.CardDeck;
import model.cards.CardDeckKlondike;
import model.cards.CardStack;


import java.io.*;
import java.util.ArrayList;

/**
 * project: ija_projekt
 * author: Adam Zivcak
 * login:  xzivca03
 * created: 1.4.2017
 */
public class KlondikeGame implements Game, Serializable {

    private static final long serialVersionUID = 1L;

    private ArrayList<CardStack> tableau = new ArrayList<>(7);
    private ArrayList<CardDeck> foundations = new ArrayList<>();
    private CardDeck mainDeck;
    private CardDeck waste = new CardDeckKlondike();
    private int score = 0;

    private FactoryKlondike factory = new FactoryKlondike();

    @Override
    public Game getGame() {
        return this;
    }

    /*public int getScore(){
        return this.score;
    }*/

    @Override
    public void saveGame(Game game, File file) {
        try {
            if(!(file.getName().endsWith(".kln")))
            {
                file = new File(file.toString() + ".kln");
            }
            FileOutputStream fos = new FileOutputStream(file);
            ObjectOutputStream oos = new ObjectOutputStream(fos);
            oos.writeObject(game);
            oos.close();
            System.err.println("...saving game... done");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    @Override
    public Game loadGame(File file) {
        try {
            if (!file.exists()) throw new IOException("subor binsubor neexistuje");

            FileInputStream fis = new FileInputStream(file);
            ObjectInputStream ois = new ObjectInputStream(fis);
            Game game = (Game) ois.readObject();
            ois.close();
            System.err.println("...loading game... done");
            return game;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * Inicializácia hry.
     * Rozloží karty na hrací plán a pripraví cieľové balíky.
     */
    @Override
    public void laidCards() {

        mainDeck = factory.createCardDeck();
        mainDeck.shuffleCards();

        for (Card.Color color : Card.Color.values()) {
            foundations.add(factory.createTargetPack(color));
        }

        for (int i = 0; i < 7; i++) {
            tableau.add(factory.createWorkingPack());
        }

        for (int i = 0; i < 7; i++) {                   // rozloženie kariet na kôpky
            for (int j = i; j < 7; j++) {
                CardStack stack = tableau.get(j);
                stack.put(mainDeck.get().color(), mainDeck.pop().value());
                if (i == j)
                    stack.get(i).rotateCard();
            }
        }
    }

    /**
     * Potiahne novú kartu zo zásobnika, ak sa tam nejaká nacházda, inak prevráti kôpku
     */
    @Override
    public void dealCard() {
        if (mainDeck.size() > 0) {
            waste.put(mainDeck.get().color(), mainDeck.pop().value());
            waste.get().rotateCard();
        } else {
            int size = this.waste.size();
            
            for (int i = 0; i < size; i++) {
                mainDeck.put(waste.get().color(), waste.pop().value());
                mainDeck.get().rotateCard();
            }
        }
    }

    /**
     * Zistí možný ťah v hre.
     */
    @Override
    public String getHint() {

        Card fromCard;
        Card toCard;
        String text;

        for (CardStack stack : tableau) {                                // beriem i-ty byliček
            for (int j = 0; j < stack.size(); j++) {
                fromCard = stack.get(j);                                // postupne beriem karty z i-teho balička

                if (fromCard.isTurnedFaceUp()) {
                    for (CardStack s : tableau) {                       // prejdenie tableau
                        if (s.checkPut(fromCard)) {
                            toCard = s.get();
                            text = ("Move " + fromCard.toString() + " to " + toCard.toString() + ".");         // todo - čo to bude vraciať ?
                            return text;
                        }
                    }
                    for (CardDeck d : foundations) {                    // prejdenie foundations
                        if (d.checkPut(fromCard)) {
                            //toCard = d.get();
                            text = ("Move " + fromCard.toString() + " to " +/* toCard.toString() +*/ "foundation.");         // todo - čo to bude vraciať ?
                            return text;
                        }}
                }
            }
        }
        if (waste.size() != 0) {
            fromCard = waste.get();
            for (CardStack st : tableau) {
                if (st.checkPut(fromCard)) {
                    toCard = st.get();
                    text = ("Move card from waste to " + toCard.toString() + ".");     // todo
                    return text;
                }
            }
            for (CardDeck deck : foundations) {
                if (deck.checkPut(fromCard)) {
                    text = ("Move card from waste to foundation");     // todo
                    return text;
                }
            }
        }
        if (mainDeck.size() != 0 || waste.size() != 0) {
            text = ("Deal card.");
            return text;// todo
        } else {
            text = ("No moves.");
            return text;// todo
        }

    }


    @Override
    public void scoring() {
        // Waste to Tableau	        ==   5
        // Waste to Foundation	    ==  10

        // Tableau to Foundation	==  10
        // Turn over Tableau card	==   5
        // Foundation to Tableau	== −15
        // Recycle waste when playing by ones	−100 (minimum score is 0)


    }
    
    @Override
    public CardStack getStack(int index)
    {
        return this.tableau.get(index);
    }
    
    @Override
    public void addScore(int value)
    {
        this.score += value;
    }
    
    @Override
    public int getScore()
    {
        return this.score;
    }
    
    @Override
    public CardDeck getMainDeck()
    {
        return this.mainDeck;
    }
    
    /**
     *
     * @return
     */
    @Override
    public CardDeck getWasteDeck()
    {
        return this.waste;
    }
}


//======================================================================================================
//======================================================================================================
//======================================================================================================
//======================================================================================================

/*
System.out.println("vypisanie baličkov kariet");
        for(int i=0;i< 7;i++){
        System.out.println(i+"-ty baliček:");
        CardStack tmpStack=tableau.get(i);
        for(int j=0;j<tmpStack.size();j++)
        {
        System.out.println("    "+j+"-ta karta: "+tmpStack.get(j).toString());
        }
        }

        for(int i=0;i<mainDeck.size();i++){
        System.out.println("karta v baliku: "+mainDeck.get(i).toString());
        }
        System.out.println("veľkosť maindecku je: "+mainDeck.size());

*/



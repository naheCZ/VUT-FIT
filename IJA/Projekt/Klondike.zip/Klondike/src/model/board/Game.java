package model.board;

import java.io.File;
import model.cards.CardDeck;
import model.cards.CardStack;

/**
 * project: ija_projekt
 * author: Adam Zivcak
 * login:  xzivca03
 * created: 31.3.2017
 */
public interface Game {

    void scoring();

    String getHint();

    void dealCard();

    void laidCards();

    //int getScore();

    Game getGame();

    void saveGame(Game game, File file);

    Game loadGame(File file);
    
    CardStack getStack(int index);
    
    void addScore(int value);
    
    int getScore();
    
    CardDeck getMainDeck();
    
    CardDeck getWasteDeck();

}
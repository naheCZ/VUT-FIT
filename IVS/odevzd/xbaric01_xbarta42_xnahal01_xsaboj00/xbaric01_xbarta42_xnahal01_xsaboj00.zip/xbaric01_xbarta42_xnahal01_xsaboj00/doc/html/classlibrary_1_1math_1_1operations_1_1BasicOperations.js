var classlibrary_1_1math_1_1operations_1_1BasicOperations =
[
    [ "addition", "classlibrary_1_1math_1_1operations_1_1BasicOperations.html#a5afc7c2019f98aa14b802d072c55ed01", null ],
    [ "division", "classlibrary_1_1math_1_1operations_1_1BasicOperations.html#a6378db262640857d9c895927e840a0cb", null ],
    [ "multiplication", "classlibrary_1_1math_1_1operations_1_1BasicOperations.html#a2ea49491769865bc62e17702d7f6164c", null ],
    [ "subtraction", "classlibrary_1_1math_1_1operations_1_1BasicOperations.html#ad6065b8d0354bad29b1359eaeec80f93", null ]
];
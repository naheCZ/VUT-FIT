var dir_5923b2f5242ecc126a44b2274131c595 =
[
    [ "AdvancedOperations.java", "AdvancedOperations_8java.html", [
      [ "AdvancedOperations", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations" ]
    ] ],
    [ "BasicOperations.java", "BasicOperations_8java.html", [
      [ "BasicOperations", "classlibrary_1_1math_1_1operations_1_1BasicOperations.html", "classlibrary_1_1math_1_1operations_1_1BasicOperations" ]
    ] ]
];
var classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest =
[
    [ "addition", "classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest.html#a9eaf2d423643f94eb8cbece6d863d2ce", null ],
    [ "division", "classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest.html#ae71639b8a8d36f43b43360553588fe10", null ],
    [ "multiplication", "classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest.html#a15d96379bf79be0bc5f049457ed46127", null ],
    [ "subtraction", "classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest.html#aca38708188cf21258d787cc20a9e9567", null ],
    [ "test_throwing_exception", "classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest.html#aee26f352c25fd5d8659285c7d2606ae3", null ]
];
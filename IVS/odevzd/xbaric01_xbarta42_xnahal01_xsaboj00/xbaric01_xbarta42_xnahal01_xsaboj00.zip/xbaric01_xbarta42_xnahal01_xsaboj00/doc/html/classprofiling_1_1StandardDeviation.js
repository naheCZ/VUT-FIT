var classprofiling_1_1StandardDeviation =
[
    [ "countResult", "classprofiling_1_1StandardDeviation.html#a7d6f2e8d4e1a424475db8c0bfccf2277", null ],
    [ "readNum", "classprofiling_1_1StandardDeviation.html#aec3ec801f015ebdc79c1f1bb2bcabb24", null ]
];
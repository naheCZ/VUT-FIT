var hierarchy =
[
    [ "library.math.operations.AdvancedOperations", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html", null ],
    [ "test.library.math.operations.AdvancedOperationsTest", "classtest_1_1library_1_1math_1_1operations_1_1AdvancedOperationsTest.html", null ],
    [ "library.math.operations.BasicOperations", "classlibrary_1_1math_1_1operations_1_1BasicOperations.html", null ],
    [ "test.library.math.operations.BasicOperationsTest", "classtest_1_1library_1_1math_1_1operations_1_1BasicOperationsTest.html", null ],
    [ "analysis.precedence.Calculator", "classanalysis_1_1precedence_1_1Calculator.html", null ],
    [ "test.analysis.precedence.CalculatorTest", "classtest_1_1analysis_1_1precedence_1_1CalculatorTest.html", null ],
    [ "profiling.Profiling", "classprofiling_1_1Profiling.html", null ],
    [ "analysis.precedence.Stack", "classanalysis_1_1precedence_1_1Stack.html", null ],
    [ "profiling.StandardDeviation", "classprofiling_1_1StandardDeviation.html", null ],
    [ "analysis.precedence.Token", "classanalysis_1_1precedence_1_1Token.html", null ],
    [ "Application", null, [
      [ "form.Main", "classform_1_1Main.html", null ]
    ] ],
    [ "Initializable", null, [
      [ "form.CalculatorController", "classform_1_1CalculatorController.html", null ]
    ] ]
];
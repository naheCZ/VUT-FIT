var classlibrary_1_1math_1_1operations_1_1AdvancedOperations =
[
    [ "absolute_value", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html#a3dc1da59db2bf9df299a1bd7740158b5", null ],
    [ "factorial", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html#af2b5c71fd78ca69ffc9b1b164539e8cb", null ],
    [ "power", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html#aab35a2991bd25efcba1cca7292eed5c4", null ],
    [ "root", "classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html#a70d2fb5e868475de47470bd3a4199c2a", null ]
];
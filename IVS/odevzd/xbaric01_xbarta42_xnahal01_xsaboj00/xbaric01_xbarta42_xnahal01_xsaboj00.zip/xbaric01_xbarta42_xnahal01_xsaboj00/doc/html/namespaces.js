var namespaces =
[
    [ "analysis", "namespaceanalysis.html", "namespaceanalysis" ],
    [ "form", "namespaceform.html", null ],
    [ "library", "namespacelibrary.html", "namespacelibrary" ],
    [ "profiler", "namespaceprofiler.html", null ],
    [ "profiling", "namespaceprofiling.html", null ],
    [ "test", "namespacetest.html", "namespacetest" ]
];
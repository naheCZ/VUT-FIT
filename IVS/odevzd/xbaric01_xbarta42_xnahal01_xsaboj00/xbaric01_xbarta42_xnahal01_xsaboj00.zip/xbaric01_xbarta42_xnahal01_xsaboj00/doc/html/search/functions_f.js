var searchData=
[
  ['readnum',['readNum',['../classprofiling_1_1StandardDeviation.html#aec3ec801f015ebdc79c1f1bb2bcabb24',1,'profiling::StandardDeviation']]],
  ['root',['root',['../classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html#a70d2fb5e868475de47470bd3a4199c2a',1,'library.math.operations.AdvancedOperations.root()'],['../classtest_1_1library_1_1math_1_1operations_1_1AdvancedOperationsTest.html#aa62376191fe312a23fc56113f7ccac4d',1,'test.library.math.operations.AdvancedOperationsTest.root()']]]
];

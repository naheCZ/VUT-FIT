var searchData=
[
  ['factorial',['factorial',['../classlibrary_1_1math_1_1operations_1_1AdvancedOperations.html#af2b5c71fd78ca69ffc9b1b164539e8cb',1,'library.math.operations.AdvancedOperations.factorial()'],['../classtest_1_1library_1_1math_1_1operations_1_1AdvancedOperationsTest.html#a35aab6927df8b60075e527d78620c1e9',1,'test.library.math.operations.AdvancedOperationsTest.factorial()']]]
];

var searchData=
[
  ['operate',['operate',['../classanalysis_1_1precedence_1_1Token.html#ac01419e02a4cc65e97700dea18917c1c',1,'analysis.precedence.Token.operate(double number1)'],['../classanalysis_1_1precedence_1_1Token.html#aedd8c9189dbebf9f1cd7f5ee2f68404a',1,'analysis.precedence.Token.operate(double number1, double number2)']]]
];

var searchData=
[
  ['stack',['Stack',['../classanalysis_1_1precedence_1_1Stack.html',1,'analysis::precedence']]],
  ['standarddeviation',['StandardDeviation',['../classprofiling_1_1StandardDeviation.html',1,'profiling']]]
];

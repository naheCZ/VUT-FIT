/*******************************************************************
 * Project: IVS project 2018
 * Package: library.math.operations
 * File: AdvancedOperations.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Class where are implemented advanced operations of calculator like factorial, nth power, absolute value and nth root.
 *******************************************************************/

/**
 * @file AdvancedOperations.java
 * @brief Class where are implemented advanced operations of calculator like factorial, nth power, absolute value and nth root.
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package library.math.operations
 * @brief Classes which are implementing math operations and functions.
 */
package library.math.operations;

/**
 * Class where are implemented advanced operations of calculator like factorial, nth power, absolute value and nth root.
 * @brief Class where are implemented advanced operations of calculator.
 */
public class AdvancedOperations
{
    /**
     * Function for calculating factorial of double value.
     * @param number Some value with no decimals and greater than -1.
     * @return Factorial of number.
     */
    public static double factorial(double number)
    {
        double result = 1.0;

        if(number < 0 || number % 1 != 0)
            throw new ArithmeticException("Factorial input error.");

        //some constants where we can instantly throw a result
        if(number==0 || number==1)
                return 1;

        //we can compute max. factorial 170! with doubles
        //for calculating result we are using our implemented basic operations

        for (int f = 2; f <= number; f++)
        {
            try
            {
                result = BasicOperations.multiplication(result, f);
            }
            catch (ArithmeticException e)
            {
                throw new ArithmeticException("Factorial overflow.");
            }
        }

        return result;
    }

    /**
     * Function for calculating power of base.
     * @param base Some value of base.
     * @param power Some value of power with no decimals and greater than -1.
     * @return Power of base.
     */
    public static double power(double base, double power)
    {
        double result = 1.0;

        //power can be only natural number(0,1,2...), power can't have decimals and if base and power are zero's it is nan
        if(power < 0 || power % 1 != 0 || (base == 0 && power == 0))
            throw new ArithmeticException("Power input error.");

        //some constants where we can instantly throw a result
        if(power == 0)
            return 1;

        if(base == 0)
            return 0;

        if(base == 1)
            return 1;

        for(double x = 0; x < power; x++)
        {
            try
            {
                result = BasicOperations.multiplication(result,base);
            }
            catch (ArithmeticException e)
            {
                throw new ArithmeticException("Power overflow.");
            }
        }

        return result;
    }

    /**
     * Function for calculating absolute value.
     * @param number Some value.
     * @return Absolute value of number.
     */
    public static double absolute_value(double number)
    {
        if(number<0)
            return BasicOperations.multiplication(number, -1);

        return number;
    }

    /**
     * Function for calculating root of base.
     * @param base Some value of base.
     * @param root Some value of root.
     * @return Root of base.
     */
    public static double root(double base, double root)
    {
        //some conditions for base and root
        if(root <= 0 || base < 0 || root % 1 != 0)
            throw new ArithmeticException("Root input error.");

        //some constants where we can instantly throw a result
        else if(root == 1)
            return base;
        else if(base == 1)
            return 1;
        else if(base == 0)
            return 0;
        else
            {
                double delta, result = BasicOperations.division(base,root);
                do
                    {
                        try
                        {
                            // delta = (base/power(result,root-1)-result)/root;
                            delta = BasicOperations.division(BasicOperations.subtraction(BasicOperations.division(base, AdvancedOperations.power(result, root-1)),result) , root);
                            result = BasicOperations.addition(result,delta);
                        }
                        catch (ArithmeticException e)
                        {
                            throw new ArithmeticException("Root overflow.");
                        }
                    }
                    //setting precision of algorithm
                    while (absolute_value(delta) >= 1e-8);

                return result;
            }

    }
}

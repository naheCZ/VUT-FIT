/*******************************************************************
 * Project: IVS project 2018
 * Package: library.math.operations
 * File: BasicOperations.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Class where are implemented basic operations of calculator like addition, subtraction, multiplication and division.
 *******************************************************************/

/**
 * @file BasicOperations.java
 * @brief Class where are implemented basic operations of calculator like addition, subtraction, multiplication and division.
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package library.math.operations
 * @brief Classes which are implementing math operations and functions.
 */
package library.math.operations;

/**
 * Class where are implemented basic operations of calculator like addition, subtraction, multiplication and division.
 * @brief Class where are implemented basic operations of calculator.
 */
public class BasicOperations
{
    /**
     * Function for calculating addition of two double values.
     * @param number1 Some value.
     * @param number2 Some value.
     * @return Result of addition.
     */
    public static double addition(double number1, double number2)
    {
        double result = number1 + number2;

        //double in Java overflows to infinity, nan is when we adds pos. and neg. infinity or pos. and neg. max. value of double
        if (Double.isInfinite(result) || Double.isNaN(result))
            throw new ArithmeticException("Addition overflow.");

        return result;
    }

    /**
     * Function for calculating subtraction of two double values.
     * @param number1 Some value.
     * @param number2 Some value.
     * @return Result of subtraction.
     */
    public static double subtraction(double number1, double number2)
    {
        double result = number1 - number2;

        if (Double.isInfinite(result) || Double.isNaN(result))
            throw new ArithmeticException("Subtraction overflow.");

        return result;
    }

    /**
     * Function for calculating multiplication of two double values.
     * @param number1 Some value.
     * @param number2 Some value.
     * @return Result of multiplication.
     */
    public static double multiplication(double number1, double number2)
    {
        double result = number1 * number2;

        if (Double.isInfinite(result) || Double.isNaN(result))
            throw new ArithmeticException("Multiplication overflow.");

        return result;
    }

    /**
     * Function for calculating division of two double values.
     * @param number1 Some value.
     * @param number2 Some value.
     * @return Result of division.
     */
    public static double division(double number1, double number2)
    {
        double result = number1 / number2;

        if (Double.isInfinite(result) || Double.isNaN(result))
            throw new ArithmeticException("Division overflow.");

        return result;
    }
}

/*******************************************************************
 * Project: IVS project 2018
 * Package: analysis.precedence
 * File: Calculator.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Implementation of methods for processing input and operating precedence analysis.
 *******************************************************************/

/**
 * @file Calculator.java
 * @brief Implementation of methods for processing input and operating precedence analysis.
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package analysis.precedence
 * @brief Classes which are processing input, evaluating expression and returning result.
 */
package analysis.precedence;


import java.util.ArrayList;

/**
 * Implementation of methods for processing input and operating precedence analysis.
 * @brief Class for evaluating entered expressions.
 */
public class Calculator
{

    /** Stack which holds operators, functions and parenthesis. */
    private Stack operators_stack;
    /** Stack which holds only values. */
    private Stack values_stack;
    /** Static variable for holding last expression result. */
    private static Token result = new Token("0.0") ;

    /**
     * Constructor creates two stacks one for operators and second for values.
     */
    public Calculator()
    {
        operators_stack = new Stack();
        values_stack = new Stack();
    }

    /**
     * Method for emptying operators a values stack.
     */
    public void empty_stacks()
    {
        operators_stack.empty();
        values_stack.empty();
    }

    /**
     * Function which firstly split entered String to tokens. Then launch syntactic_analysis for checking if factorial or absolute value are correctly entered. And then launch precedence analysis for evaluating expression.
     * @param input Mathematical expression.
     * @return Result of mathematical expression.
     */
    public double process_input(String input)
    {
        //get rid off whitespace
        input.replaceAll("\\s+", "");

        Token[] tokens = string_to_tokens(input);

        syntactic_analysis(tokens);

        precedence_analysis(tokens);

        // storing result in static class member result
        result = values_stack.top();

        //after popping out result from values stack it has to be empty
        values_stack.pop();

        if (!operators_stack.is_empty() || !values_stack.is_empty())
        {
            throw new IllegalStateException("Precedence analysis error.");
        }
        else
        {
            return result.get_value();
        }
    }

    /**
     *  Method for processing operator t, given by parameter. It takes and pops out values from value stack.
     * @param t Operator or function to process.
     */
    private void process_operator(Token t)
    {
        Token A = null, B = null, R = null;

        switch (t.get_type())
        {
            //processing operators and functions, which needs two values from value stack
            case Token.PLUS:
            case Token.MINUS:
            case Token.TIMES:
            case Token.DIVISION:
            case Token.POWER:
            case Token.ROOT:
            {
                if (values_stack.is_empty())
                {
                    throw new IllegalStateException();
                }
                else
                {
                    B = values_stack.top();
                    values_stack.pop();
                }

                if (values_stack.is_empty())
                {
                    throw new IllegalStateException();
                }
                else
                {
                    A = values_stack.top();
                    values_stack.pop();
                }

                //processing root operator, it needs two values from value stack but in different order
                if (t.get_type() == Token.ROOT)
                {
                    R = t.operate(B.get_value(), A.get_value());
                }
                else
                {
                    R = t.operate(A.get_value(), B.get_value());
                }

                //pushing result to value stack
                values_stack.push(R);
                break;
            }
            //processing operators and functions, which needs only one value
            case Token.ABSOLUTE_VALUE:
            case Token.FACTORIAL:
            {
                if (values_stack.is_empty())
                {
                    throw new IllegalStateException();
                }
                else
                {
                    A = values_stack.top();
                    values_stack.pop();
                }

                R = t.operate(A.get_value());

                values_stack.push(R);
                break;
            }

        } // end of switch

    } //process_operator()

    /**
     * Function for splitting entered expression into tokens.
     * @param input Mathematical expression written like a string.
     * @return Array of tokens.
     */
    public Token[] string_to_tokens(String input)
    {

        // Input expression is splitted into  string parts and they are stored in this collection.
        ArrayList<String> parts = new ArrayList<String>();

        Character number_or_dot;

        //going through string character by character, finding what can be token and adding it to ArrayList
        for (int i = 0; i < input.length(); i++)
        {
            switch (input.charAt(i))
            {
                case '+':
                    parts.add("+");
                    break;

                case '-':
                    parts.add("-");
                    break;

                case '*':
                    parts.add("*");
                    break;

                case '/':
                    parts.add("/");
                    break;

                case '(':
                    parts.add("(");
                    break;

                case ')':
                    parts.add(")");
                    break;

                case '!':
                    parts.add("!");
                    break;

                case '^':
                    parts.add("^");
                    break;

                case '\u221A':
                    parts.add("\u221A");
                    break;

                case 'A':

                    i++;
                    //deciding if token is Abs or Ans
                    if (input.charAt(i) == 'b')
                    {
                        parts.add("Abs");
                    }
                    else
                    {
                        parts.add("Ans");
                    }
                    i++;
                    break;

                default:

                    //processing double values which can start by dot or number
                    if (input.charAt(i) == '.' || Character.isDigit(input.charAt(i)))
                    {
                        String whole_double = "";

                        if(parts.size() > 0)
                        {
                            //if there is one extra + or - operator, it's fine we can convert it only to one operator, for example -+ it's converted to -
                            if(parts.get(parts.size()-1).equals("+") || parts.get(parts.size()-1).equals("-"))
                            {
                                if(parts.size() == 1)
                                {
                                    whole_double = parts.get(parts.size()-1);
                                    parts.remove(parts.size()-1);
                                }
                                else if(parts.size() > 1)
                                {
                                    if(parts.get(parts.size()-2).equals("+") || parts.get(parts.size()-2).equals("-") || parts.get(parts.size()-2).equals("*") || parts.get(parts.size()-2).equals("/") || parts.get(parts.size()-2).equals("^") || parts.get(parts.size()-2).equals("\u221A")|| parts.get(parts.size()-2).equals("(") || parts.get(parts.size()-2).equals("!") || parts.get(parts.size()-2).equals("Abs"))
                                    {
                                        whole_double = parts.get(parts.size()-1);
                                        parts.remove(parts.size()-1);
                                    }
                                }
                            }
                        }

                        number_or_dot = input.charAt(i);
                        int number_of_dots = 0;

                        //merging into string while we processing numbers or dot
                        do
                        {
                            if (number_or_dot == '.')
                                number_of_dots++;

                            //double value can have only one dot
                            if (number_of_dots > 1)
                                throw new NumberFormatException("Lexical analysis error.");

                            whole_double = whole_double + number_or_dot;
                            i++;

                            if (i == input.length())
                                break;

                            number_or_dot = input.charAt(i);


                        } while (Character.isDigit(number_or_dot) || number_or_dot == '.');

                        i--;

                        //double value must have at least one number, before dot 5. after dot .5 dot or 5.5
                        if (whole_double.equals("."))
                            throw new NumberFormatException("Lexical analysis error.");


                        parts.add(whole_double);

                    } // processing double values

            } //end of switch

        } // end of cycle for processing input

        // Array where will be stored all of tokens from input.
        Token[] tokens = new Token[parts.size()];

        for (int n = 0; n < parts.size(); n++)
        {
            //calling token constructor for every part
            tokens[n] = new Token(parts.get(n));
        }

        return tokens;

    } //string_to_tokens()

    /**
     * Syntactic analysis checks  what can be before factorial and absolute value. It throws exception if something is wrong.
     * @param tokens Input expression splitted to tokens.
     */
    public void syntactic_analysis(Token[] tokens)
    {
        for (int n = 0; n < tokens.length; n++)
        {
            switch (tokens[n].get_type())
            {
                case Token.FACTORIAL:
                {
                    if (n == 0)
                        throw new IllegalStateException("Syntactic analysis error.");

                    if (!(tokens[n - 1].get_type() == Token.RIGHT_PARENTHESIS || tokens[n - 1].get_type() == Token.NUMBER || tokens[n - 1].get_type() == Token.FACTORIAL))
                        throw new IllegalStateException("Syntactic analysis error.");
                    break;
                }

                case Token.ABSOLUTE_VALUE:
                {
                    if (n != 0)
                        if (tokens[n - 1].get_type() == Token.FACTORIAL || tokens[n - 1].get_type() == Token.NUMBER || tokens[n - 1].get_type() == Token.ANS)
                            throw new IllegalStateException("Syntactic analysis error.");

                    break;
                }
            }
        }
    }

    /**
     * Method for evaluating expression by loading and processing tokens given by parameter.
     * @param tokens Input expression splitted to tokens.
     */
    public void precedence_analysis(Token[] tokens)
    {
        //going through all tokens in token array and evaluating.
        for (int n = 0; n < tokens.length; n++)
        {
            Token next_token = tokens[n];

            switch (next_token.get_type())
            {
                //if token is number it is pushed to value stack
                case Token.NUMBER:
                    values_stack.push(next_token);
                    break;

                //if token is answer it is pushed to value stack as result of last expression(on start result is initialized on zero)
                case Token.ANS:
                    values_stack.push(result);
                    break;

                //if token is left parenthesis it is pushed to operators stack
                case Token.LEFT_PARENTHESIS:
                    operators_stack.push(next_token);
                    break;

                // pushing operators to operators stack instantly or processing them ,it depends on next conditions
                case Token.PLUS:
                case Token.MINUS:
                case Token.TIMES:
                case Token.DIVISION:
                case Token.POWER:
                case Token.ROOT:
                case Token.ABSOLUTE_VALUE:
                case Token.FACTORIAL:
                {
                    // pushing operator to operators stack if condition is true
                    if (operators_stack.is_empty() || next_token.get_precedence() > operators_stack.top().get_precedence())
                    {
                        operators_stack.push(next_token);
                    }

                    else
                    {
                        //processing operators until condition is true and then we can push next_token to operators stack
                        while (!operators_stack.is_empty() && next_token.get_precedence() <= operators_stack.top().get_precedence())
                        {
                            Token to_process = operators_stack.top();
                            operators_stack.pop();
                            try
                            {
                                process_operator(to_process);
                            }
                            catch (IllegalStateException e)
                            {
                                throw new IllegalStateException("Precedence analysis error.");
                            }
                        }
                        operators_stack.push(next_token);
                    }

                    break;
                }

                //if token is right parenthesis then operators in stack before left parenthesis need to be processed
                case Token.RIGHT_PARENTHESIS:
                {
                    //operators in parenthesis need to be processed until we hit on left parenthesis
                    while (!operators_stack.is_empty() && (operators_stack.top().get_type() == Token.PLUS || operators_stack.top().get_type() == Token.MINUS || operators_stack.top().get_type() == Token.TIMES || operators_stack.top().get_type() == Token.DIVISION || operators_stack.top().get_type() == Token.POWER || operators_stack.top().get_type() == Token.ROOT || operators_stack.top().get_type() == Token.ABSOLUTE_VALUE|| operators_stack.top().get_type() == Token.FACTORIAL))
                    {
                        Token to_process = operators_stack.top();
                        operators_stack.pop();
                        try
                        {
                            process_operator(to_process);
                        }
                        catch (IllegalStateException e)
                        {
                            throw new IllegalStateException("Precedence analysis error.");
                        }
                    }

                    //popping out left parenthesis
                    if (!operators_stack.is_empty() && operators_stack.top().get_type() == Token.LEFT_PARENTHESIS)
                    {
                        operators_stack.pop();
                    }
                    else
                    {
                        throw new IllegalStateException("Precedence analysis error.");
                    }

                    break;
                }

            } // end of switch

        } // end of for cycle which goes through all of token from input

        // if we have still some operators in operators stack we need to process them until operators stack is empty
        while (!operators_stack.is_empty() && (operators_stack.top().get_type() == Token.PLUS || operators_stack.top().get_type() == Token.MINUS || operators_stack.top().get_type() == Token.TIMES || operators_stack.top().get_type() == Token.DIVISION || operators_stack.top().get_type() == Token.POWER || operators_stack.top().get_type() == Token.ROOT || operators_stack.top().get_type() == Token.ABSOLUTE_VALUE || operators_stack.top().get_type() == Token.FACTORIAL))
        {
            Token to_process = operators_stack.top();
            operators_stack.pop();
            try
            {
                process_operator(to_process);
            }
            catch (IllegalStateException e)
            {
                throw new IllegalStateException("Precedence analysis error.");
            }
        }

    } //precedence_analysis()

}

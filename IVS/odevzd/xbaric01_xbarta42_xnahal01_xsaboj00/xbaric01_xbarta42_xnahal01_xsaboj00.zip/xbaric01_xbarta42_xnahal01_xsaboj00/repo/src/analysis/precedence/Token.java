/*******************************************************************
 * Project: IVS project 2018
 * Package: analysis.precedence
 * File: Token.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Implementation of token object. One token represents part of mathematical expression(numbers, operators, parenthesis, functions).
 *******************************************************************/

/**
 * @file Token.java
 * @brief Implementation of token object. One token represents part of mathematical expression(numbers, operators, parenthesis, functions).
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package analysis.precedence
 * @brief Classes which are processing input, evaluating expression and returning result.
 */
package analysis.precedence;

import library.math.operations.AdvancedOperations;
import library.math.operations.BasicOperations;

/**
 * Implementation of token object. One token represents part of mathematical expression(numbers, operators, parenthesis, functions).
 * @brief Implementation of token object.
 */
public class Token
{
    /** Constant for initial state of token. */
    public static final int INITIAL = -1;
    /** Constant for number type of token. */
    public static final int NUMBER = 0;
    /** Constant for addition type of token. */
    public static final int PLUS = 1;
    /** Constant for subtraction type of token. */
    public static final int MINUS = 2;
    /** Constant for multiplication type of token. */
    public static final int TIMES = 3;
    /** Constant for division  type of token. */
    public static final int DIVISION = 4;
    /** Constant for factorial type of token. */
    public static final int FACTORIAL = 5;
    /** Constant for power type of token. */
    public static final int POWER = 6;
    /** Constant for root type of token. */
    public static final int ROOT = 7;
    /** Constant for absolute value type of token. */
    public static final int ABSOLUTE_VALUE = 8;
    /** Constant for left parenthesis type of token. */
    public static final int LEFT_PARENTHESIS = 9;
    /** Constant for right parenthesis type of token. */
    public static final int RIGHT_PARENTHESIS = 10;
    /** Constant for answer type of token. */
    public static final int ANS = 11;

    /** Type of token can be one of constant values. */
    private int type;
    /** Only type number has stored value in this variable. */
    private double value;
    /** Types for operators and functions have some precedence based on mathematical rules. Greater precedence, more important is operator. */
    private int precedence;

    /**
     * Empty constructor initialize token to type initial(-1).
     */
    public Token()
    {
        type = INITIAL;
    }

    /**
     * Constructor initialize token's type, precedence and value based on string given as parameter.
     * @param value String which will be converted to token.
     */
    public Token(String value)
    {

        switch(value)
        {
            case "+":
                type = PLUS;
                precedence = 1;
                break;

            case "-":
                type = MINUS;
                precedence = 1;
                break;

            case "*":
                type = TIMES;
                precedence = 2;
                break;

            case "/":
                type = DIVISION;
                precedence = 2;
                break;

            case "!":
                type = FACTORIAL;
                precedence = 4;
                break;

            case "^":
                type = POWER;
                precedence = 3;
                break;

            case "\u221A":
                type = ROOT;
                precedence = 3;
                break;

            case "Abs":
                type = ABSOLUTE_VALUE;
                precedence = 4;
                break;

            case "(":
                type = LEFT_PARENTHESIS;
                break;

            case ")":
                type = RIGHT_PARENTHESIS;
                break;

            case "Ans":
                type = ANS;
                break;

            default:
                type = NUMBER;
                try
                {
                    this.value = Double.parseDouble(value);
                } catch (Exception e)
                {
                    type = INITIAL;
                }

        } // end of switch

    } // Token()

    /**
     * Constructor initialize token's type and value.
     * @param x Number which will be converted to token.
     */
    public Token(double x)
    {
        type = NUMBER;
        value = x;
    }

    /**
     * Function which returns type of token.
     * @return Type of token.
     */
    int get_type()
    {
        return type;
    }

    /**
     * Function which returns value of token. Only number type of token has value.
     * @return Value of token.
     */
    double get_value()
    {
        return value;
    }

    /**
     * Function which returns precedence of operator or function.
     * @return Precedence of token.
     */
    int get_precedence()
    {
        return precedence;
    }

    /**
     * Function for calling operations, operation is based on caller's type.
     * @param number1 Some value.
     * @return Result of operation represented in type of number token.
     */
    Token operate(double number1)
    {
        double result = 0;

        switch(type)
        {
            case FACTORIAL:
                result = AdvancedOperations.factorial(number1);
                break;

            case ABSOLUTE_VALUE:
                result = AdvancedOperations.absolute_value(number1);
                break;
        }

        return new Token(result);
    }

    /**
     * Function for calling operations, operation is based on caller's type.
     * @param number1 Some value.
     * @param number2 Some value.
     * @return Result of operation represented in type of number token .
     */
    Token operate(double number1,double number2)
    {

        double result = 0;

        switch(type)
        {
            case PLUS:
                result = BasicOperations.addition(number1,number2);
                break;

            case MINUS:
                result = BasicOperations.subtraction(number1,number2);
                break;

            case TIMES:
                result = BasicOperations.multiplication(number1,number2);
                break;

            case DIVISION:
                result = BasicOperations.division(number1,number2);
                break;

            case POWER:
                result = AdvancedOperations.power(number1,number2);
                break;

            case ROOT:
                result = AdvancedOperations.root(number1,number2);
                break;

        } // end of switch

        return new Token(result);

    } // operate()
}

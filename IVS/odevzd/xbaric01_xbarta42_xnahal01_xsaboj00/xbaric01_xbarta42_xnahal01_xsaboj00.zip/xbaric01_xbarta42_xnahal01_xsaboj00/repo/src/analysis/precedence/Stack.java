/*******************************************************************
 * Project: IVS project 2018
 * Package: analysis.precedence
 * File: Stack.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Implementation of token stack by collection ArrayList.
 *******************************************************************/

/**
 * @file Stack.java
 * @brief Implementation of token stack by collection ArrayList.
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package analysis.precedence
 * @brief Classes which are processing input, evaluating expression and returning result.
 */
package analysis.precedence;

import java.util.ArrayList;

/**
 * Implementation of token stack by collection ArrayList.
 * @brief Implementation of token stack.
 */
public class Stack
{
    /** Collection ArrayList where are stored all of stack tokens. */
    private ArrayList<Token> tokens;

    /**
     * Constructor of token stack.
     */
    public Stack()
    {
        tokens = new ArrayList<Token>();
    }

    /**
     * Function which says if stack is empty or not.
     * @return True, if stack is empty, otherwise false.
     */
    public boolean is_empty()
    {
        return tokens.size() == 0;
    }

    /**
     * Function which returns token on top of the stack.
     * @return Token on top of the stack.
     */
    public Token top()
    {
        return tokens.get(tokens.size()-1);
    }

    /**
     * Method pushes token on top of the stack.
     * @param t Token which we want to push on top of the stack.
     */
    public void push(Token t)
    {
        tokens.add(t);
    }

    /**
     * Method which pops out token on top of the stack.
     */
    public void pop()
    {
        tokens.remove(tokens.size()-1);
    }

    /**
     * Method which will empty the stack.
     */
    public void empty()
    {
        if(!this.is_empty())
            this.pop();
    }

}

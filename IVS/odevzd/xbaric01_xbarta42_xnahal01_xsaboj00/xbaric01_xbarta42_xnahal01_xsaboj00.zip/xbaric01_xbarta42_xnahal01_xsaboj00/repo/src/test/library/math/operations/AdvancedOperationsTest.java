/*******************************************************************
 * Project: IVS project 2018
 * Folder: test
 * Package: library.math.operations
 * File: AdvancedOperationsTest.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Class for testing advanced operations of math library with JUnit5.0 .
 *******************************************************************/

/**
 * @file AdvancedOperationsTest.java
 * @brief Class for testing advanced operations of math library with JUnit5.0 .
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package library.math.operations
 * @brief Classes which are implementing math operations and functions.
 */
package test.library.math.operations;

import library.math.operations.AdvancedOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

/** Class for testing advanced operations of math library with JUnit5.0 .
 * @brief Test class for advanced math operations.
 */
class AdvancedOperationsTest
{
    /** Variable where are stored exceptions. */
    Executable test_throwing_exception;

    /**
     * Test functionality of factorial.
     */
    @Test
    void factorial()
    {
        assertEquals( 1, AdvancedOperations.factorial(0), "Basic_test1");
        assertEquals( 1, AdvancedOperations.factorial(1), "Basic_test2");
        assertEquals( 2, AdvancedOperations.factorial(2), "Basic_test3");
        assertEquals( 1.307674368E12, AdvancedOperations.factorial(15), "Basic_test4");

        //maximum factorial which we can compute with double data type is 170!
        assertEquals( 7.257415615307994E306, AdvancedOperations.factorial(170), "Basic_test5");

        //negative input numbers tests
        test_throwing_exception = () ->AdvancedOperations.factorial(-1);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test1");

        test_throwing_exception = () ->AdvancedOperations.factorial(-235);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test2");

        //bigger factorials then we can compute
        test_throwing_exception = () ->AdvancedOperations.factorial(171);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test3");

        test_throwing_exception = () ->AdvancedOperations.factorial(2347);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test4");

        test_throwing_exception = () ->AdvancedOperations.factorial(Double.MAX_VALUE);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test5");

        //decimal value tests
        test_throwing_exception = () ->AdvancedOperations.factorial(0.1478);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test6");

        test_throwing_exception = () ->AdvancedOperations.factorial(15.1);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test7");

        test_throwing_exception = () ->AdvancedOperations.factorial(Double.MIN_VALUE);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test8");
    }

    /**
     * Test functionality of power.
     */
    @Test
    void power()
    {
        assertEquals( 1, AdvancedOperations.power(1,0), "Zero_power_test1");
        assertEquals( 1, AdvancedOperations.power(1254,0), "Zero_power_test2");
        assertEquals( 1, AdvancedOperations.power(Double.MAX_VALUE,0), "Zero_power_test3");
        assertEquals( 1, AdvancedOperations.power(Double.MIN_VALUE,0), "Zero_power_test4");
        assertEquals( 1, AdvancedOperations.power(-1,0), "Zero_power_test5");

        assertEquals( 4, AdvancedOperations.power(2,2), "Basic_tests_1");
        assertEquals( 4096, AdvancedOperations.power(16,3), "Basic_tests_2");
        assertEquals( Double.MAX_VALUE, AdvancedOperations.power(Double.MAX_VALUE,1), "Basic_tests_3");
        assertEquals( 7.650840793839573E94, AdvancedOperations.power(514,35), "Basic_tests_4");
        assertEquals( 1, AdvancedOperations.power(1,1), "Basic_tests_5");
        assertEquals( 1, AdvancedOperations.power(1,15), "Basic_tests_6");
        assertEquals( 0, AdvancedOperations.power(0,Double.MAX_VALUE), "Basic_tests_7");
        assertEquals( 1, AdvancedOperations.power(1,Double.MAX_VALUE), "Basic_tests_8");

        assertEquals( 4, AdvancedOperations.power(-2,2), "Negative_base_tests_1");
        assertEquals( -8, AdvancedOperations.power(-2,3), "Negative_base_tests_2");
        assertEquals( 1.9175105923288404E35, AdvancedOperations.power(-15,30), "Negative_base_tests_3");
        assertEquals( 1, AdvancedOperations.power(-1,0), "Negative_base_tests_4");
        assertEquals( 1, AdvancedOperations.power(-1,14), "Negative_base_tests_5");
        assertEquals( -Double.MAX_VALUE, AdvancedOperations.power(-Double.MAX_VALUE,1), "Negative_base_tests_6");

        test_throwing_exception = () ->AdvancedOperations.power(0,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test1");

        test_throwing_exception = () ->AdvancedOperations.power(1,-154);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test2");

        test_throwing_exception = () ->AdvancedOperations.power(1,10.4);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test3");

        test_throwing_exception = () ->AdvancedOperations.power(1500,350);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Overflow_test1");
        test_throwing_exception = () ->AdvancedOperations.power(2,Double.MAX_VALUE);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Overflow_test2");

        assertEquals( 0, AdvancedOperations.power(0.0001,1000), "Underflow_test1");
    }

    /**
     * Test functionality of absolute_value.
     */
    @Test
    void absolute_value()
    {
        assertEquals( 0, AdvancedOperations.absolute_value(0), "Basic_test1");
        assertEquals( 252, AdvancedOperations.absolute_value(252), "Basic_test2");
        assertEquals( 14, AdvancedOperations.absolute_value(-14), "Basic_test3");
        assertEquals( Double.MAX_VALUE, AdvancedOperations.absolute_value(-Double.MAX_VALUE), "Basic_test4");
    }

    /**
     * Test functionality of root.
     */
    @Test
    void root()
    {
        assertEquals( 0, AdvancedOperations.root(0, 2125), "Zero_base_test1");
        assertEquals( 0, AdvancedOperations.root(0, Double.MAX_VALUE), "Zero_base_test2");
        assertEquals( 1, AdvancedOperations.root(1, 1414), "One_base_test1");
        assertEquals( 1, AdvancedOperations.root(1, Double.MAX_VALUE), "One_base_test2");

        assertEquals( 3543543, AdvancedOperations.root(3543543, 1), "One_root_test1");
        assertEquals( Double.MAX_VALUE, AdvancedOperations.root(Double.MAX_VALUE,1 ), "One_root_test2");

        test_throwing_exception = () ->AdvancedOperations.root(5421,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test1");

        test_throwing_exception = () ->AdvancedOperations.root(Double.MAX_VALUE,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test2");

        test_throwing_exception = () ->AdvancedOperations.root(4,2.0001);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test3");

        test_throwing_exception = () ->AdvancedOperations.root(16,15.4654);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test4");

        test_throwing_exception = () ->AdvancedOperations.root(256,-2);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test5");

        test_throwing_exception = () ->AdvancedOperations.root(-14,10);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Wrong_input_test6");

        assertEquals( 2, AdvancedOperations.root(4,2), "Basic_test1");
        assertEquals( 5, AdvancedOperations.root(125,3), "Basic_test2");
        assertEquals( 25, AdvancedOperations.root(9765625,5), "Basic_test3");
        assertEquals( 3, AdvancedOperations.root(14348907,15), "Basic_test4");
        assertEquals( 32, AdvancedOperations.root(1.1805916e+21,14), 0.0000001, "Basic_test5");

        assertEquals( 1.780026091, AdvancedOperations.root(5.64,3),0.0000001, "Advanced_test1");
        assertEquals( 1.092406029, AdvancedOperations.root(8.341,24),0.0000001, "Advanced_test2");
        assertEquals( 314.2696805, AdvancedOperations.root(98765.4321,2),0.0000001, "Advanced_test3");
        assertEquals( 1.025379337, AdvancedOperations.root(213.45,214),0.0000001, "Advanced_test4");
    }

}

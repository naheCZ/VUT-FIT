/*******************************************************************
 * Project: IVS project 2018
 * Folder: test
 * Package: library.math.operations
 * File: BasicOperationsTest.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Class for testing basic operations of math library with JUnit5.0 .
 *******************************************************************/

/**
 * @file BasicOperationsTest.java
 * @brief Class for testing basic operations of math library with JUnit5.0 .
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package library.math.operations
 * @brief Classes which are implementing math operations and functions.
 */
package test.library.math.operations;

import library.math.operations.BasicOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

/** Class for testing basic operations of math library with JUnit5.0 .
 * @brief Test class for basic math operations.
 */
class BasicOperationsTest
{
    /**  Variable where are stored exceptions. */
    Executable test_throwing_exception;

    /**
     * Test functionality of adding.
     */
    @Test
    void addition()
    {
        //basic tests
        assertEquals( 1, BasicOperations.addition(0,1), "Basic_test1");
        assertEquals( 1, BasicOperations.addition(1,0), "Basic_test2");
        assertEquals( -25, BasicOperations.addition(-35.4,10.4),"Basic_test3");
        assertEquals( 0, BasicOperations.addition(999999999999.99999999,-999999999999.99999999), "Basic_test4");

        //max. value of double tests, adding not important number to double max. value is still max. value by Java implementation
        assertEquals( Double.MAX_VALUE, BasicOperations.addition(Double.MAX_VALUE,123456.76), "Max_value_test1");
        assertEquals( Double.MAX_VALUE, BasicOperations.addition(Double.MAX_VALUE,-123456.76), "Max_value_test2");
        assertEquals( 0, BasicOperations.addition(Double.MAX_VALUE, -Double.MAX_VALUE), "Max_value_test3");

        //throwing exceptions tests
        test_throwing_exception = () -> BasicOperations.addition(Double.MAX_VALUE,Double.MAX_VALUE);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Max_value_test4");

        //advanced test with infinites, calculator do not work with them but mathematical library should know how to handle them
        test_throwing_exception = () -> BasicOperations.addition(Double.POSITIVE_INFINITY, 9999);;
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test1");


        test_throwing_exception = () ->   BasicOperations.addition(-9999,Double.NEGATIVE_INFINITY);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test2");


        test_throwing_exception = () -> BasicOperations.addition(Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test3");
    }

    /**
     * Test functionality of subtraction.
     */
    @Test
    void subtraction()
    {
        assertEquals( 0, BasicOperations.subtraction(0,0), "Basic_test1");
        assertEquals( -1, BasicOperations.subtraction(0,1), "Basic_test2");
        assertEquals( 1, BasicOperations.subtraction(1,+0), "Basic_test3");
        assertEquals( -45.8, BasicOperations.subtraction(-35.4,10.4),"Basic_test4");
        assertEquals( 0, BasicOperations.subtraction(-999999999999.99999999,-999999999999.99999999), "-999999999999.99999999 - -999999999999.99999999)");

        assertEquals( Double.MAX_VALUE, BasicOperations.subtraction(Double.MAX_VALUE,123456.76), "Max_value_test1");
        assertEquals( Double.MAX_VALUE, BasicOperations.subtraction(Double.MAX_VALUE,-123456.76), "Max_value_test2");
        assertEquals( 0, BasicOperations.subtraction(Double.MAX_VALUE, Double.MAX_VALUE), "Max_value_test3");

        test_throwing_exception = () -> BasicOperations.subtraction(Double.MAX_VALUE,-Double.MAX_VALUE);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Max_value_test4");

        test_throwing_exception = () -> BasicOperations.subtraction(Double.POSITIVE_INFINITY, 14545);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test1");

        test_throwing_exception = () -> BasicOperations.subtraction(14545,Double.NEGATIVE_INFINITY);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test2");

        test_throwing_exception = () -> BasicOperations.subtraction(Double.POSITIVE_INFINITY,Double.POSITIVE_INFINITY);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test3");
    }

    /**
     * Test functionality of multiplication.
     */
    @Test
    void multiplication()
    {
        assertEquals( 0, BasicOperations.multiplication(0,0), "Basic_test1");
        assertEquals( 0, BasicOperations.multiplication(0,1), "Basic_test2");
        assertEquals( 0, BasicOperations.multiplication(1,+0), "Basic_test3");
        assertEquals( -354, BasicOperations.multiplication(-35.4,10),"Basic_test4");
        assertEquals( 41504.4638, BasicOperations.multiplication(45.8,906.211), "Basic_test5");
        assertEquals( 25, BasicOperations.multiplication(-5,-5), "Basic_test6");

        assertEquals( 0, BasicOperations.multiplication(Double.MAX_VALUE,0), "Max_value_test1");
        assertEquals( Double.MAX_VALUE, BasicOperations.multiplication(Double.MAX_VALUE,1), "Max_value_test2");

        test_throwing_exception = () -> BasicOperations.multiplication(Double.MAX_VALUE,2);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Max_value_test3");

        test_throwing_exception = () -> BasicOperations.multiplication(Double.MAX_VALUE,Double.MAX_VALUE);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Max_value_test4");

        //when you underflow java double value you get 0
        assertEquals( Double.MIN_VALUE, BasicOperations.multiplication(Double.MIN_VALUE,1), "Min_value_test1");
        assertEquals( 0, BasicOperations.multiplication(Double.MIN_VALUE,0.1), "Min_value_test2");
        assertEquals( 0, BasicOperations.multiplication(Double.MIN_VALUE,Double.MIN_VALUE), "Min_value_test3");

        test_throwing_exception = () -> BasicOperations.multiplication(Double.POSITIVE_INFINITY,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test1");

        test_throwing_exception = () -> BasicOperations.multiplication(Double.POSITIVE_INFINITY,1);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test2");

        test_throwing_exception = () -> BasicOperations.multiplication(Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test3");
    }

    /**
     * Test functionality of division.
     */
    @Test
    void division()
    {
        assertEquals( 1, BasicOperations.division(1,1), "Basic_test1");
        assertEquals( 0, BasicOperations.division(0,1), "Basic_test2");
        assertEquals( -3.54, BasicOperations.division(-35.4,10),"Basic_test3");
        assertEquals( 7.75, BasicOperations.division(124,16), "Basic_test4");
        assertEquals( 1, BasicOperations.division(-5,-5), "Basic_test5");

        assertEquals( 0, BasicOperations.division(0,Double.MAX_VALUE), "Max_value_test1");
        assertEquals(true,1>BasicOperations.division(1,Double.MAX_VALUE), "Max_value_test2");
        assertEquals( Double.MAX_VALUE, BasicOperations.division(Double.MAX_VALUE,1), "Max_value_test3");
        assertNotEquals( Double.MAX_VALUE, BasicOperations.division(Double.MAX_VALUE,2), "Max_value_test4");
        assertEquals( 1, BasicOperations.division(Double.MAX_VALUE,Double.MAX_VALUE), "Max_value_test5");

        assertEquals( Double.MIN_VALUE, BasicOperations.division(Double.MIN_VALUE,1), "Min_value_test1");
        assertNotEquals( 0, BasicOperations.division(Double.MIN_VALUE,0.1), "Min_value_test2");
        assertEquals( 0, BasicOperations.division(Double.MIN_VALUE,10), "Min_value_test2");
        assertEquals( 1, BasicOperations.division(Double.MIN_VALUE,Double.MIN_VALUE), "Min_value_test3");

        test_throwing_exception = () -> BasicOperations.division(1,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Dividing_zero_test1");

        test_throwing_exception = () -> BasicOperations.division(Double.MAX_VALUE,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Dividing_zero_test2");

        test_throwing_exception = () -> BasicOperations.division(Double.POSITIVE_INFINITY,45);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test1");

        test_throwing_exception = () -> BasicOperations.division(Double.POSITIVE_INFINITY,0);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test2");

        test_throwing_exception = () -> BasicOperations.division(Double.POSITIVE_INFINITY,Double.NEGATIVE_INFINITY);
        assertThrows(ArithmeticException.class, test_throwing_exception, "Infinity_test3");
    }

}

/*******************************************************************
 * Project: IVS project 2018
 * Folder: test
 * Package: analysis.precedence
 * File: CalculatorTest.java
 * Date: 24.3.2018
 * Last change: 27.3.2018
 * Author: Jozef Sabo xsaboj00@stud.fit.vutbr.cz
 * Description: Class for testing if precedence analysis correctly evaluate expressions with JUnit5.0 .
 *******************************************************************/

/**
 * @file CalculatorTest.java
 * @brief Class for testing if precedence analysis correctly evaluate expressions with JUnit5.0 .
 * @author Jozef Sabo (xsaboj00)
 */

/**
 * @package analysis.precedence
 * @brief Classes which are processing input, evaluating expression and returning result.
 */
package test.analysis.precedence;

import analysis.precedence.Calculator;
import library.math.operations.AdvancedOperations;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.function.Executable;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Class for testing if precedence analysis correctly evaluate expressions with JUnit5.0 .
 * @brief Test class for checking evaluations of expressions.
 */
class CalculatorTest
{

    /** Variable where are stored exceptions. */
    Executable test_throwing_exception;

    /**
     * Test functionality of evaluation expressions.
     */
    @Test
    void process_input()
    {
        Calculator calculator = new Calculator();

        //NumberFormat exceptions are for errors in lexical analysis.
        //IllegalState exceptions are for errors in precedence analysis.

        assertEquals( 1455, calculator.process_input("1455"), "Only_value_test1");
        assertEquals( -6.89798, calculator.process_input("-6.89798"), "Only_value_test2");
        assertEquals( +.45, calculator.process_input("+.45"), "Only_value_test3");
        assertEquals( -16.5, calculator.process_input("-16.5"), "Only_value_test4");
        assertEquals( .15, calculator.process_input(".15"), "Only_value_test5");

        test_throwing_exception = () -> calculator.process_input(".");
        assertThrows(NumberFormatException.class, test_throwing_exception, "Wrong_value_input_test1");

        test_throwing_exception = () -> calculator.process_input("5.45.");
        assertThrows(NumberFormatException.class, test_throwing_exception, "Wrong_value_input_test2");

        test_throwing_exception = () -> calculator.process_input("5.45.45");
        assertThrows(NumberFormatException.class, test_throwing_exception, "Wrong_value_input_test3");

        test_throwing_exception = () -> calculator.process_input("...");
        assertThrows(NumberFormatException.class, test_throwing_exception, "Wrong_value_input_test4");

        test_throwing_exception = () -> calculator.process_input("5..4");
        assertThrows(NumberFormatException.class, test_throwing_exception, "Wrong_value_input_test5");

        assertEquals( 10, calculator.process_input("5+5"), "Basic_test1");
        assertEquals( -11, calculator.process_input("-5-6"), "Basic_test2");
        assertEquals( 200, calculator.process_input("5*40"), "Basic_test3");
        assertEquals( 10, calculator.process_input("90/9"), "Basic_test4");
        assertEquals( 3125, calculator.process_input("5^5"), "Basic_test5");
        assertEquals( 5, calculator.process_input("2\u221A25"), "Basic_test6");
        assertEquals( 120, calculator.process_input("5!"), "Basic_test7");
        assertEquals( 0, calculator.process_input("Ans - 120"), "Basic_test8");
        assertEquals( 8, calculator.process_input("Abs-8"), "Basic_test9");
        assertEquals( 80, calculator.process_input("8*(5+5)"), "Basic_test10");
        assertEquals( 726, calculator.process_input("6+(6!)"), "Basic_test11");
        assertEquals( 30, calculator.process_input("6+(2+2)!"), "Basic_test11");
        assertEquals( 732, calculator.process_input("6+(6+6!)"), "Basic_test12");


        test_throwing_exception = () -> calculator.process_input("5+5+");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test1");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("5**5");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test2");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("5^*6");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test3");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("41-4)");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test4");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("8 Abs-4");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test5");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("8^");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test6");
        calculator.empty_stacks();

        //don't forget to enter root, it's required
        test_throwing_exception = () -> calculator.process_input("\u221A16");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_input_test7");
        calculator.empty_stacks();

        //one extra plus or minus to value are typically allowed in calculators
        assertEquals( 10, calculator.process_input("5++5"), "Extra_plus_minus_test1");
        assertEquals( -11, calculator.process_input("-5-+6"), "Extra_plus_minus_test2");
        assertEquals( -200, calculator.process_input("-5*40"), "Extra_plus_minus_test3");
        assertEquals( -10, calculator.process_input("90/-9"), "Extra_plus_minus_test4");
        assertEquals( 3125, calculator.process_input("5^+5"), "Extra_plus_minus_test5");
        assertEquals( 3125, calculator.process_input("5^(+5)"), "Extra_plus_minus_test6");

        test_throwing_exception = () -> calculator.process_input("++5");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_extra_plus_minus_input_test1");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("8++-9");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_extra_plus_minus_input_test2");
        calculator.empty_stacks();

        //there can ca be spaces in textfield
        assertEquals( 9, calculator.process_input("5   +     Abs      (5-9)"), "Advanced_test1");
        assertEquals( 17, calculator.process_input("((5+12)*(4-3))"), "Advanced_test2");
        assertEquals( 6.034176337, calculator.process_input("Abs(5\u221A20^3)"),0.0000001, "Advanced_test3");
        assertEquals( 0.034176337, calculator.process_input("Abs(5\u221A20^3)-(+3)!"),0.0000001, "Advanced_test4");
        assertEquals( 3.034176337, calculator.process_input("Abs(5\u221A20^3)-Abs-3"),0.0000001, "Advanced_test5");
        assertEquals( 3.034176337, calculator.process_input("Abs(5\u221A20^3)-Abs(+3)"),0.0000001, "Advanced_test6");
        assertEquals( 243.160395430, calculator.process_input("Ans^5-14*(0.2*5)"),0.0000001, "Advanced_test7");
        assertEquals( 720, calculator.process_input("3!!"), "Advanced_test8");
        assertEquals( 729, calculator.process_input("3!! + Abs-9"), "Advanced_test9");
        assertEquals( 738, calculator.process_input("3!! + Abs(-9)*2"), "Advanced_test10");
        assertEquals( 792, calculator.process_input("3!! + Abs(-9)*2^3"), "Advanced_test11");
        assertEquals( 6552, calculator.process_input("3!! + (Abs(-9)*2)^3"), "Advanced_test12");
        assertEquals( 5, calculator.process_input("(((5)))"), "Advanced_test13");
        assertEquals( -1, calculator.process_input("(((5)))-((9-7)\u221A36)"), "Advanced_test14");
        assertEquals( 1, calculator.process_input("Abs((((5)))-((9-7)\u221A36))"), "Advanced_test15");
        assertEquals( 5, calculator.process_input("5^Abs((((5)))-((9-7)\u221A36))"), "Advanced_test16");


        test_throwing_exception = () -> calculator.process_input("5   +*     Abs      (5-9)");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test1");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("((5+12)*(4-3)");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test2");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("Abs(\u221A20^3)-(+3)!");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test3");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("!5");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test4");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("4+!5");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test5");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("5+Abs");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test6");
        calculator.empty_stacks();

        test_throwing_exception = () -> calculator.process_input("5Abs");
        assertThrows(IllegalStateException.class, test_throwing_exception, "Wrong_advanced_input_test7");
        calculator.empty_stacks();
    }
}

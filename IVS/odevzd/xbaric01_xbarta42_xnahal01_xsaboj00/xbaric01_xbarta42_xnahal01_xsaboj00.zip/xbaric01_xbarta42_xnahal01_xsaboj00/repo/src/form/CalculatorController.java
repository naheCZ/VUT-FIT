package form;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.event.ActionEvent;
import javafx.scene.Cursor;
import javafx.scene.ImageCursor;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.control.Tooltip;
import javafx.scene.input.KeyEvent;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import analysis.precedence.*;
import library.math.operations.*;

public class CalculatorController implements Initializable
{
    //Tlacitka pro cislice
    @FXML
    private Button zeroButton;
    @FXML
    private Button oneButton;
    @FXML
    private Button twoButton;
    @FXML
    private Button threeButton;
    @FXML
    private Button fourButton;
    @FXML
    private Button fiveButton;
    @FXML
    private Button sixButton;
    @FXML
    private Button sevenButton;
    @FXML
    private Button eightButton;
    @FXML
    private Button nineButton;
    @FXML
    private Button dotButton;

    //Tlacitka pro matematiku
    @FXML
    private Button plusButton;
    @FXML
    private Button minusButton;
    @FXML
    private Button mulButton;
    @FXML
    private Button divButton;
    @FXML
    private Button powerButton;
    @FXML
    private Button rootButton;
    @FXML
    private Button leftBracketButton;
    @FXML
    private Button rightBracketButton;
    @FXML
    private Button equalsButton;
    @FXML
    private Button factorialButton;

    //Tlacitko pro ovladani textu
    @FXML
    private Button backButton;
    @FXML
    private Button cButton;
    @FXML
    private Button ceButton;

    //Tlacitko pre napovedu
    @FXML
    private Button helpButton;

    //Textova pole
    @FXML
    private TextField problemTextField;
    @FXML
    private TextField writeTextField;

    @FXML
    private GridPane buttonsGridPane;

    private Calculator calculator;
    
    private boolean isHelpButtonClicked;

    private javafx.scene.image.Image helpCursor;

    public CalculatorController() {
        this.helpCursor = new Image("/images/Cursor.png");
        this.isHelpButtonClicked = false;
    }

    @FXML
    private void handleHelpButtonAction(ActionEvent event)
    {
        if(!this.isHelpButtonClicked){
            this.showHelp();
        } else {
            this.hideHelp();
        }
    }

    @FXML
    private void handleNumberButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        String previousText = this.writeTextField.getText();
        Button button = (Button) event.getSource();

        if(previousText.equals("0"))
            previousText = "";

        this.writeTextField.setText(previousText + this.buttonToString(button));
    }

    @FXML
    private void handleOperationButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        String previousText = this.writeTextField.getText();
        String previousProblem = this.problemTextField.getText();
        Button button = (Button) event.getSource();

        if(previousText.equals("") && this.lastChar(previousProblem) != ')'&& this.lastChar(previousProblem) != '!')
            previousText = "0";

        if(!(previousText.equals("")) && this.lastChar(previousProblem) == ')')
            previousProblem = previousProblem + "*";

        if(lastChar(previousText) == '.')
            previousText += "0";

        this.problemTextField.setText(previousProblem + previousText + this.buttonToString(button));
        this.writeTextField.setText("");
    }

    @FXML
    private void handleDotButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        String previousText = this.writeTextField.getText();

        if(previousText.equals(""))
            previousText = "0";

        if(!(previousText.contains(".")))
            this.writeTextField.setText(previousText + ".");

    }

    @FXML
    private void handleCButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        this.problemTextField.setText("");
        this.writeTextField.setText("0");
    }

    @FXML
    private void handleCeButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        this.writeTextField.setText("0");
    }

    @FXML
    private void handleBackspaceButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        String previousText = this.writeTextField.getText();

        if(previousText.length() != 0)
            this.writeTextField.setText(previousText.substring(0, previousText.length() - 1));
    }

    @FXML
    private void handleBracersButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        Button button = (Button) event.getSource();
        String bracer = button.getText();
        String previousProblem = this.problemTextField.getText();
        String previousText = this.writeTextField.getText();
        int numberOfLeft;
        int numberOfRight;

        if(bracer.equals("(") && (this.lastChar(previousProblem) != ')'))
            this.problemTextField.setText(previousProblem + bracer);

        else
        {
            numberOfLeft = this.numberOfChar(previousProblem, '(');
            numberOfRight = this.numberOfChar(previousProblem, ')');

            if(previousText.equals("") && lastChar(previousProblem) != '!')
                previousText = "0";

            if(previousProblem.contains("(") && (numberOfLeft - numberOfRight > 0))
            {
                this.problemTextField.setText(previousProblem + previousText + bracer);
                this.writeTextField.setText("");
            }
        }
    }

    /**
     * Checks if equation expects operand at the end
     * @param equation String with equation
     * @return boolean
     */
    private boolean expectsOperand(String equation)
    {
        switch (lastChar(equation))
        {
            case ')':
            case '!':
                return false;
            default:
                return true;
        }
    }


    @FXML
    private void handleCalculateButtonAction(ActionEvent event)
    {
        if(this.isHelpButtonClicked){
            this.hideHelp();
        }
        String previousText = this.writeTextField.getText();
        String previousProblem = this.problemTextField.getText();
        String problem;
        int diff = this.numberOfChar(previousProblem, '(') - this.numberOfChar(previousProblem, ')');
        double result=0.0;

        if(diff > 0)
        {
            this.addBracers(diff);
            previousProblem = this.problemTextField.getText();
        }

        if(previousText.equals("") && this.expectsOperand(previousProblem))
            previousText = "0";

        if(lastChar(previousText) == '.')
            previousText += "0";

        problem = previousProblem + previousText;
        try
        {
            result = this.calculator.process_input(problem);
        }
        catch (Exception e)
        {
            calculator.empty_stacks();
            this.problemTextField.setText("");
            this.writeTextField.setText("ERR");
            return;
        }

        if(result % 1 == 0)
            this.writeTextField.setText(Integer.toString((int) result));

        else
            this.writeTextField.setText(Double.toString(result));

        this.problemTextField.setText("");

    }

    @FXML
    private void handleOnKeyPressed(KeyEvent event)
    {
        Button fireButton;

        fireButton = keyToButton(event.getText());

        if(fireButton != null)
            fireButton.fire();
    }

    /**
     * Return number of char in string
     * @param string String
     * @param ch Char to count
     * @return int
     */
    private int numberOfChar(String string, char ch)
    {
        int count = 0;

        for(char c: string.toCharArray())
        {
            if(c == ch)
                count++;
        }

        return count;
    }

    /**
     * Return last char in string
     * @param string String
     * @return char
     */
    private char lastChar(String string)
    {
        if(string.equals(""))
            return 0;

        return string.charAt(string.length() - 1);
    }

    /**
     * Add missing bracers to string
     * @param diff Number of missing bracers
     */
    private void addBracers(int diff)
    {
        String previousProblem = this.problemTextField.getText();

        if(this.lastChar(previousProblem) == '(')
            this.problemTextField.setText(previousProblem + "0");

        for(int i = 0; i < diff; i++)
        {
            previousProblem = this.problemTextField.getText();

            this.problemTextField.setText(previousProblem + ")");
        }
    }

    /**
     * Return last char in string
     * @param key String, where
     * @return Button
     */
    private Button keyToButton(String key)
    {
        ArrayList<Button> buttons = new ArrayList<>();
        Button button = null;

        for(Node node : buttonsGridPane.getChildren())
            buttons.add((Button) node);

        for(Button b : buttons)
        {
            if(b.getText().equals(key))
            {
                button = b;
                break;
            }
        }

        return button;
    }

    /**
     * Cast Button to String
     * @param button Button
     * @return String
     */
    private String buttonToString(Button button)
    {
        return button.getText();
    }

    /**
     * Show help message
     */
    private void showHelp()
    {
        this.isHelpButtonClicked = true;
        this.helpButton.getScene().setCursor(new ImageCursor(this.helpCursor));
        this.backButton.setTooltip( new Tooltip("Clear last input"));
        this.cButton.setTooltip( new Tooltip("Clear all"));
        this.ceButton.setTooltip( new Tooltip("Clear input"));
        this.divButton.setTooltip(new Tooltip("Division"));
        this.mulButton.setTooltip(new Tooltip("Multiplication"));
        this.dotButton.setTooltip(new Tooltip("Floating point"));
        this.equalsButton.setTooltip(new Tooltip("Result"));
        this.leftBracketButton.setTooltip(new Tooltip("Opening parenthesis"));
        this.rightBracketButton.setTooltip(new Tooltip("Closing parenthesis"));
        this.minusButton.setTooltip(new Tooltip("Substraction"));
        this.plusButton.setTooltip(new Tooltip("Addition"));
        this.factorialButton.setTooltip(new Tooltip("Factorial"));
        this.powerButton.setTooltip(new Tooltip("Power operator"));
        this.rootButton.setTooltip(new Tooltip("Root operator"));
        this.writeTextField.setTooltip(new Tooltip("Input field"));
        this.problemTextField.setTooltip(new Tooltip("Entire equation"));
    }

    /**
     * Hide help message
     */
    private void hideHelp()
    {
        this.isHelpButtonClicked = false;
        this.helpButton.getScene().setCursor(Cursor.DEFAULT);
        this.backButton.setTooltip(null);
        this.cButton.setTooltip(null);
        this.ceButton.setTooltip(null);
        this.divButton.setTooltip(null);
        this.mulButton.setTooltip(null);
        this.dotButton.setTooltip(null);
        this.equalsButton.setTooltip(null);
        this.leftBracketButton.setTooltip(null);
        this.rightBracketButton.setTooltip(null);
        this.rightBracketButton.setTooltip(null);
        this.minusButton.setTooltip(null);
        this.plusButton.setTooltip(null);
        this.factorialButton.setTooltip(null);
        this.powerButton.setTooltip(null);
        this.rootButton.setTooltip(null);
        this.writeTextField.setTooltip(null);
        this.problemTextField.setTooltip(null);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources)
    {
        this.calculator = new Calculator();
    }
}

/*******************************************************************
 * Project: IVS project 2018
 * Package: profiler
 * File: StandardDeviation.java
 * Date: 22.4.2018
 * Last change: 23.4.2018
 * Author: Filip Baric xbaric01@vutbr.cz
 * Description: Contains function for reading numbers from stdin and standard deviation function.
 *******************************************************************/

/**
 * @file StandardDeviation.java
 * @brief Program which count standard deviation of given numbers, created for profiling purposes only.
 * @author Filip Baric (xbaric01)
 */

/**
 * @package profiler
 * @brief Classes which are implementing standard deviation function.
 */
package profiling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import library.math.operations.*;

/**
 * Class where are implemented operations of program like reading numbers etc.
 * @brief Class where are implemented operations of standard deviation program.
 */
public class StandardDeviation {
    
    /**
    * Function for calculating standard deviation.
    * @return List of numbers.
    */    
    public static List<Double> readNum() {
    
        //save input from stdin
        String string = "";
        //converted double from string
        double convert;
        //array of numbers from input
        List<Double> numbers = new ArrayList<Double>();
        
        //reading from input, convert string to double and save to arraylist
        try{

            BufferedReader bufferRead = new BufferedReader(new InputStreamReader(System.in));

            while(((string=bufferRead.readLine())!= null) && !("".equals(string))) {
                try{
                    convert = Double.parseDouble(string);
                }
                catch(NumberFormatException e){
                    System.err.println(string+" Is not a number!\n");
                    return null;
                }
                numbers.add(convert);
            }
            //kontrola poctu cisel
            if(numbers.size() == 0) {
                System.err.println("Missing numbers!\n");
                return null;
            }
        }   
        catch(IOException e)
        {
                e.printStackTrace();
        }
        return numbers;
    }
    /**
    * Function for calculating standard deviation.
    * @param numbers List of given numbers.
    * @return Result of standard deviation.
    */ 
    public static double countResult(List<Double> numbers) {   
            
            
        //arithmetic mean
        double arit = 0;
        //sum used in function snadard deviation
        double sum = 0;
        //squared arithmetic mean
        double arit2 = 0;
        //result of snadard deviation
        double result = 0;
        //squared arithmetic mean multiplied by count of numbers
        double minus = 0;
        //squared numbers from input
        double item2 = 0;

        //sum of numbers from list
        for(Double item : numbers ) {
            sum = BasicOperations.addition(sum,item);
        }

        arit = BasicOperations.division(sum, numbers.size());
        arit2 = AdvancedOperations.power(arit, 2);
        minus = BasicOperations.multiplication(arit2, numbers.size());

        //reset
        sum = 0;

        //sum of squared numbers from list
        for(Double item : numbers ) {
            item2 = AdvancedOperations.power(item, 2);
            sum = BasicOperations.addition(sum, item2);
        }

        sum = BasicOperations.subtraction(sum, minus);

            
        if(BasicOperations.subtraction(numbers.size(), 1) == 0) {
            //result of standard deviation function
            result = AdvancedOperations.root(sum,2);
        }
        else {
            //result of standard deviation function
            result = AdvancedOperations.root(BasicOperations.division(sum,BasicOperations.subtraction(numbers.size(),1)), 2);
        }
            
        return result;
    }
}
/*** End of file StandardDeviation.java ***/
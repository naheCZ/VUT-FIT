/*******************************************************************
 * Project: IVS project 2018
 * Package: profiler
 * File: Profiling.java
 * Date: 22.4.2018
 * Last change: 23.4.2018
 * Author: Filip Baric xbaric01@vutbr.cz
 * Description: Program which count standard deviation of given numbers, created for profiling purposes only.
 *******************************************************************/

/**
 * @file Profiling.java
 * @brief Program which count standard deviation of given numbers, created for profiling purposes only.
 * @author Filip Baric (xbaric01)
 */

/**
 * @package profiler
 * @brief Classes which are implementing standard deviation function.
 */
package profiling;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import library.math.operations.*;
import profiling.StandardDeviation;

/**
 * Main class.
 */
public class Profiling {
    
    /**
    * Main function.
    */
    public static void main(String[] args) {

        List<Double> read;
        double result;
        read = StandardDeviation.readNum();
        
        if(read != null) {
            result = StandardDeviation.countResult(read);
            System.out.println(result);
        }
    }
}
/*** End of file Profiler.java ***/
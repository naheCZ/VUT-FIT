# IVS2018
Repozitár na projekt IVS 2018

Prostredi
---------

Windows 64bit

Autori
------

THE DREAMEST OF THE DREAM TEAMS
- xbaric01 Filip Barič , Bc.	
- xbarta42 Radovan Bartánus , Bc.	
- xnahal01 Roman Nahálka 
- xsaboj00 Jozef Sabo 

Licence
-------

Tento program je poskytovan pod licencí GNU GPL v.3


/**
 * Problém čtenářů a písařů
 * Projekt do IOS 2012
 * Autor: Milan Falešník
 * Trošku jsem si upravil jazyk C, aby se lépe psaly procesy :)
 */
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <time.h>
#include <string.h>
#include <signal.h>
#include <semaphore.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/shm.h>
#include <sys/sem.h>
#include <sys/ipc.h>
#include <errno.h>

/**
 * DEFINICE
 */

// Zkrácení foru na generování procesů
#define foreach(i, min, max) for(int i = min; i <= max; ++i)
// Vytvoření dítěte a zápis do tabulky pid
#define spawn(child, id, pidArray) do {pid_t pid = fork(); if(pid == 0){child; fclose(sharedMemory->output); shmdt(sharedMemory); exit(EXIT_SUCCESS); }else if(pid == -1){shmdt(sharedMemory); die("Stala se chyba pri generovani procesu " #child "!");} pidArray[id-1] = pid;} while(false)
// Deklarace tabulky pid -Pid Array
#define PA(x) pid_t pid_##x[params.x##Count]
// Wait Pids - počká na všechny procesy v tabulce pid
#define WP(x) do{ for(int i = 0; i < params.x##Count; ++i) waitpid(pid_##x[i], NULL, 0); } while(false)
// Přenos dané položky z parametrů do sdílené paměti Memory Transfer from Parameter
#define MTP(what) M(what, params.what)
// Naforkuje daný počet procesů z parametrů
#define spawnProc(proc) foreach(id, 1, params.proc##Count) spawn(proc##Process(sharedMemory, id), id, pid_##proc);
// Přístup do sdílené paměti
#define M(x, y) sharedMemory->x = y
// Uspání procesu
#define work(x) usleep(randomNumber((sharedMemory->sim##x) * 1000))
// Výpis Akce
#define A(action) P(semOutput); fprintf(sharedMemory->output, "%d: %s: %d: " action "\n", sharedMemory->actionCounter++, who, id); V(semOutput)
// Definice procesu
#define process(proc) void proc##Process_(SharedMemory *sharedMemory, int id, char *who); void proc##Process(SharedMemory *sharedMemory, int id) {proc##Process_(sharedMemory, id, #proc);} void proc##Process_(SharedMemory *sharedMemory, int id, char *who)
// Získávání parametrů příkazové řádky
#define NARG(arrSubscr, target, paramId, minimum) do{if(sscanf(argv[arrSubscr], FMT_UI, &(result->target)) != 1){fprintf(stderr, "Parametr " #paramId " spatne zadan (%s)!\n", argv[arrSubscr]); return false;} if(result->target < minimum){fprintf(stderr, "Nespravne zadani parametru " #paramId " (%d)!\n", result->target); return false;} }while(false)
// Test, pokud bylo provedeno přerušení


typedef enum ParamValues {EXENAME = 0, WRITERCOUNT = 1, READERCOUNT = 2, CYCLECOUNT = 3, SIMWRITER = 4, SIMREADER = 5, OUTPUT = 6} ParamValues; /**< Enum s konstantami pro zacházení s parametry příkazové řádky */

typedef struct Params
{
    int writerCount;    /**< Počet písařů */
    int readerCount;    /**< Počet čtenářů */
    int cycleCount;     /**< Počet cyklů */
    int simWriter;      /**< Rozsah pro simulaci času písaře */
    int simReader;      /**< Rozsah pro simulaci času čtenáře */
    FILE *output;    /**< Výstupní soubor */
} Params;

typedef struct SharedMemory
{
    // Parametry
    int simWriter;
    int simReader;
    int cycleCount;
    FILE *output;
    // Sdílené údaje
    int sharedSpace;    /**< Sdílený prostor, do kterého si všichni malují */
    int actionCounter;   /**< Čítač akcí */
    int readCount;      /**< Čítač čtení */
    int writeCount;     /**< Čítač zápisů */
    sem_t semWrite;     /**< Semafor, chránící writeCount */
    sem_t semRead;      /**< Semafor, chránící readCount */
    sem_t semWriting;   /**< Semafor, chránící psaní */
    sem_t semReading;   /**< Semafor, chránící čtení */
    sem_t semReader;    /**< Semafor čtenáře */
    sem_t semOutput;    /**< Semafor chránící čítač akcí a výstup */
} SharedMemory;

const int PROJ_ID = 42;               /**< Identifikátor pro ftok() */
const char OUTPUT_STDOUT[] = "-";     /**< Identifikace výstupu na stdout */
const char FMT_UI[] = "%d";           /**< Formát načítaných číselných parametrů */

/// Atomický příznak násilného ukončení programu
volatile sig_atomic_t interrupt = false;

/// Obsluha přerušení
void handleInterrupt(int interruptCode)
{
    if(interruptCode == SIGINT)
        interrupt = true;
}


/*
 * FUNKCE
 */

/**
 * @brief Operace PROBEREN semaforu s testováním
 * @param sem Semafor
 * @return true - všechno v pořádku || false - chyba
 */
bool semProberen(sem_t *sem)
{
    if(sem_wait(sem) == -1)
        return false;
    else
        return true;
}

/**
 * @brief Operace VERHOGEN semaforu s testováním
 * @param sem Semafor
 * @return true - všechno v pořádku || false - chyba
 */
bool semVerhogen(sem_t *sem)
{
    if(sem_post(sem) == -1)
        return false;
    else
        return true;
}

/**
 * @brief Testovací funkce pro ověřování
 * @param message Zpráva uživateli
 */
void die(char *message)
{
    fprintf(stderr, "die: %s\n:(\n", message);
    exit(EXIT_FAILURE);
}

/** Přemakrování výše uvedených funkcí pro zjednodušení zápisu **/
#define P(s) if(!semProberen(&(sharedMemory->s))) do { shmdt(sharedMemory); die("P(" #s ") failed"); } while(false)
#define V(s) if(!semVerhogen(&(sharedMemory->s))) do { shmdt(sharedMemory); die("V(" #s ") failed"); } while(false)

/**
 * @brief Inicializace semaforu
 * @param sem Semafor pro inicializaci
 * @return true - úspěch | false - neúspěch
 */
bool semInit(sem_t *sem)
{
    if(sem_init(sem, 1, 1) < 0)
        return false;
    else
        return true;
}

/** Přemakrování inicializace semaforu ve sdílené paměti */
#define S(s) semInit(&(sharedMemory->s))

/**
 * @brief Ničení semaforů
 * @param sem Semafor ke zničení
 * @return true - úspěch | false - neúspěch
 */
bool semDestroy(sem_t *sem)
{
    if(sem_destroy(sem) < 0)
        return false;
    else
        return true;
}

/** Přemakrování ničení semaforu ve sdílené paměti **/
#define D(s) semDestroy(&(sharedMemory->s))


/**
 * @brief Zpracování parametrů + nastavení zadaného vstupního souboru z parametrů
 * @param argc Počet argumentů
 * @param argv Obsah argumentů
 * @param result Cílová struktura pro uložení nastavených dat
 * @return true - úspěch, vše OK | false - neúspěch. není třeba řešit hlášky vně.
 */
bool paramsParse(int argc, char *argv[], Params *result)
{
    // Počet argumentů (7)
    if(argc != 7)
    {
        fprintf(stderr, "Pouziti: $ ./readerWriter W R C S1 S2 OUT\n");
        return false;
    }
    
    // Počet písařů
    NARG(WRITERCOUNT, writerCount, W, 0);
    // Počet čtenářů
    NARG(READERCOUNT, readerCount, R, 0);
    // Počet cyklů
    NARG(CYCLECOUNT, cycleCount, C, 0);
    // Simulační čas pro písaře
    NARG(SIMWRITER, simWriter, S1, 0);
    // Simulační čas pro čtenáře
    NARG(SIMREADER, simReader, S2, 0);
    // Výstupní soubor
    if(strcmp(argv[OUTPUT], "-") == 0)
    {   // Budeme dělat výstup do stdoutu
        result->output = stdout;
    }
    else
    {   // Výstup do souboru
        result->output = fopen(argv[OUTPUT], "w");
        if(result->output == NULL)
        {
            fprintf(stderr, "Nepodarilo se otevrit soubor '%s' pro zapis, mate smulu!\n", argv[OUTPUT]);
            return false;
        }
    }
    
    setbuf(result->output, NULL);   // Bez bufferu
    
    return true;
}

/**
 * @brief V případě, že je deskriptor souborem, zavře ho
 * @param file Deskriptor souboru
 */
void closeFile(FILE *file)
{
    if(file != stdout && file != NULL)
        fclose(file);
}

/**
 * @brief Vygenerování pseudonáhodného čísla v daném rozsahu
 * @param range Rozsah generovaného čísla
 */
int randomNumber(int range)
{
    return (range != 0) ? ((int) (rand() % range)) : 0;
}

/**
 * @brief Proces čtenáře
 */
process(reader)
{
    int valueRead = -1;
    do
    {
        A("ready");
        P(semReader);
        P(semReading);
        P(semRead);
        A("reads a value");                
        // Čtu
        valueRead = sharedMemory->sharedSpace;
        P(semOutput);
        fprintf(sharedMemory->output, "%d: reader: %d: read: %d\n", sharedMemory->actionCounter++, id, valueRead);
        V(semOutput);
        (sharedMemory->readCount)++;
        if(sharedMemory->readCount == 1)
        {
            P(semWriting);
        }
        V(semRead);
        V(semReading);
        V(semReader);
        P(semRead);
        (sharedMemory->readCount)--;
        if(sharedMemory->readCount == 0)
        {
            V(semWriting);    
        }
        V(semRead);
        work(Reader);
    }
    while(valueRead != 0);
    
    return;
}

/**
 * @brief Proces písaře
 */
process(writer)
{
    int cycles = sharedMemory->cycleCount;
    while(cycles-- > 0)
    {
        A("new value");
        // Simuluje výpočet
        work(Writer);
        // Připraven zapisovat
        A("ready");
        P(semWrite);
        (sharedMemory->writeCount)++;
        if(sharedMemory->writeCount == 1)
        {
            P(semReading);
        }
        V(semWrite);
        // Písař píše
        P(semWriting);
        // Výpis těsně před zápisem
        P(semOutput);
        fprintf(sharedMemory->output, "%d: writer: %d: writes a value\n", (sharedMemory->actionCounter)++, id);
        // Zápis
        sharedMemory->sharedSpace = id;
        // Výpis těsně po zápisu
        fprintf(sharedMemory->output, "%d: writer: %d: written\n", (sharedMemory->actionCounter)++, id);
        V(semOutput);
        V(semWriting);
        P(semWrite);
        (sharedMemory->writeCount)--;
        if(sharedMemory->writeCount == 0)
        {
            V(semReading);
        }
        V(semWrite);
        
    }
    
    return;
}

/**
 * @brief Hlavní funkce programu
 * @param argc Počet předaných argumentů
 * @param argv Obsah předaných argumentů
 * @return EXIT_SUCCESS V případě úspěchu | EXIT_FAILURE v případě neúspěchu
 */
#undef A
int main(int argc, char *argv[])
{
    srand(time(NULL));
    Params params;
    if(!paramsParse(argc, argv, &params))
        return EXIT_FAILURE;
    
    key_t shmToken = ftok(argv[EXENAME], PROJ_ID);    // Identifikační token sdílené paměti
    if(shmToken == -1)
    {   // Chyba
        fprintf(stderr, "Nepodarilo se ziskat token sdilene pameti!\n");
        closeFile(params.output);
        return EXIT_FAILURE;
    }
    
    // Přidělení sdílené paměti
    int shmId = shmget(shmToken, sizeof(SharedMemory), IPC_CREAT | 0700);
    if(shmId == -1)
    {   // Přidělení se nezdařilo
        fprintf(stderr, "Nepodarilo se naalokovat sdilenou pamet!\n");
        closeFile(params.output);
        return EXIT_FAILURE;
    }
    
    // Připojení sdílené paměti
    SharedMemory *sharedMemory = shmat(shmId, NULL, 0);
    if(sharedMemory == NULL)
    {   // Připojení se nezdařilo
        fprintf(stderr, "Nepodarilo se pripojit sdilenou pamet!\n");
        closeFile(params.output);
        return EXIT_FAILURE;
    }
    
    MTP(simReader);
    MTP(simWriter);
    MTP(cycleCount);
    MTP(output);
    M(readCount, 0);
    M(writeCount, 0);
    M(sharedSpace, -1);
    M(actionCounter, 1);
    
    // Inicializace semaforů
    S(semRead);
    S(semWrite);
    S(semReader);
    S(semReading);
    S(semWriting);
    S(semOutput);
    
    // Inicializace polí pro uchování pid generovaných procesů
    PA(writer);
    PA(reader);
    
    /* START SIMULACE */
    /// generování písařů
    spawnProc(writer);
    /// generování čtenářů
    spawnProc(reader);
    
    // Čekání na Godota
    WP(writer);

    // Zápis nuly
    P(semWriting);
    M(sharedSpace, 0);
    V(semWriting);
    
    // Čekání na čtenáře
    WP(reader);
    
    /* KONEC SIMULACE */
    
    // Zrušíme semafory
    D(semRead);
    D(semWrite);
    D(semReader);
    D(semReading);
    D(semWriting);
    D(semOutput);
    
    fclose(sharedMemory->output);
    
    // Odpojení sdílené paměti
    shmdt(sharedMemory);
    
    // Zrušení sdílené paměti
    shmctl(shmId, IPC_RMID, NULL);
    
    return EXIT_SUCCESS;
}

# Testy ISA POP3 server

V prázdné (!!!) složce udělej git clone. Nakopíruj sem arhiv xlogin00.tar, který budeš odevzdávat do WIS. Spusť skript is_it_ok.sh (bez parametrů) a hlavně se nedívej, jak prasácky to je napsané!

V případě, že testuješ ne jiném stroji než merlin nebo eva, vlož napevno do proměnné myLogin na řádku 8 svůj login.

Testují se formální náležitosti a následně je spuštěn test: https://github.com/atepr/isa-pop3-server-tests
Pokud chceš pouze test formálnosti, odkomentuj exit 0 na řádku 57.
Enjoy!
